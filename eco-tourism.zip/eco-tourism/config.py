import os

class Config:
    SECRET_KEY = 'eco-tourism-secret-key-2026'
    
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    UPLOAD_FOLDER = os.path.join(BASE_DIR, 'uploads')
    
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024
    DATABASE = 'eco_tourism.db'
    
    @staticmethod
    def init_app(app):
        os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)
        os.makedirs(os.path.join(Config.UPLOAD_FOLDER, 'avatars'), exist_ok=True)