from flask import Blueprint, render_template, jsonify, request
from ..models.database import get_db
from ..utils.decorators import login_required, get_current_user
from ..achievements import check_and_award_achievements, add_xp

favorites_bp = Blueprint('favorites', __name__)


@favorites_bp.route('/favorites')
@login_required
def favorites_page():
    """Страница избранного пользователя"""
    user = get_current_user()
    conn = get_db()
    
    # Избранные наблюдения
    favorite_obs = conn.execute('''
        SELECT f.*, o.*, s.name as species_name, u.username as author_name, u.id as author_id
        FROM favorites f
        JOIN observations o ON f.item_id = o.id AND f.item_type = 'observation'
        JOIN species s ON o.species_id = s.id
        JOIN users u ON o.user_id = u.id
        WHERE f.user_id = ? AND f.item_type = 'observation'
        ORDER BY f.created_at DESC
    ''', (user['id'],)).fetchall()
    
    # Избранные маршруты
    favorite_routes = conn.execute('''
        SELECT f.*, r.*, u.username as author_name, u.id as author_id
        FROM favorites f
        JOIN eco_routes r ON f.item_id = r.id AND f.item_type = 'route'
        JOIN users u ON r.created_by = u.id
        WHERE f.user_id = ? AND f.item_type = 'route'
        ORDER BY f.created_at DESC
    ''', (user['id'],)).fetchall()
    
    conn.close()
    return render_template('favorites.html', user=user, 
                         favorite_obs=favorite_obs, 
                         favorite_routes=favorite_routes)


@favorites_bp.route('/api/favorites/toggle', methods=['POST'])
@login_required
def toggle_favorite():
    """Добавить или удалить из избранного"""
    data = request.get_json()
    item_type = data.get('type')
    item_id = data.get('id')
    user = get_current_user()
    
    conn = get_db()
    
    # Проверяем, есть ли уже в избранном
    existing = conn.execute('''
        SELECT id FROM favorites WHERE user_id = ? AND item_type = ? AND item_id = ?
    ''', (user['id'], item_type, item_id)).fetchone()
    
    if existing:
        # Удаляем из избранного
        conn.execute('DELETE FROM favorites WHERE id = ?', (existing['id'],))
        conn.commit()
        conn.close()
        return jsonify({'favorited': False, 'message': 'Удалено из избранного'})
    else:
        # Добавляем в избранное
        
        # Если это лайк наблюдения, начисляем опыт автору
        if item_type == 'observation':
            observation = conn.execute('SELECT user_id FROM observations WHERE id = ?', (item_id,)).fetchone()
            if observation and observation['user_id'] != user['id']:
                add_xp(observation['user_id'], 5, 'получение лайка на наблюдение')
                check_and_award_achievements(observation['user_id'])
        
        conn.execute('''
            INSERT INTO favorites (user_id, item_type, item_id, created_at)
            VALUES (?, ?, ?, datetime("now", "localtime"))
        ''', (user['id'], item_type, item_id))
        
        conn.commit()
        conn.close()
        return jsonify({'favorited': True, 'message': 'Добавлено в избранное'})


@favorites_bp.route('/api/favorites/check')
@login_required
def check_favorites():
    """Проверить, какие элементы в избранном"""
    user = get_current_user()
    conn = get_db()
    
    favorites = conn.execute('''
        SELECT item_type, item_id FROM favorites WHERE user_id = ?
    ''', (user['id'],)).fetchall()
    
    conn.close()
    
    result = {}
    for fav in favorites:
        key = f"{fav['item_type']}_{fav['item_id']}"
        result[key] = True
    
    return jsonify(result)