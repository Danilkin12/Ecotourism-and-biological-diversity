from flask import Blueprint, render_template, jsonify, request
from ..models.database import get_db
from ..utils.decorators import admin_required, get_current_user

admin_bp = Blueprint('admin', __name__)

@admin_bp.route('/admin')
@admin_required
def admin_panel():
    user = get_current_user()
    search_query = request.args.get('search', '')
    conn = get_db()
    
    stats = {
        'users': conn.execute('SELECT COUNT(*) as count FROM users').fetchone()['count'],
        'observations': conn.execute('SELECT COUNT(*) as count FROM observations').fetchone()['count'],
        'species': conn.execute('SELECT COUNT(*) as count FROM species').fetchone()['count'],
        'routes': conn.execute('SELECT COUNT(*) as count FROM eco_routes').fetchone()['count'],
        'pending_species': conn.execute('SELECT COUNT(*) as count FROM species WHERE status = "pending"').fetchone()['count'],
        'pending_routes': conn.execute('SELECT COUNT(*) as count FROM eco_routes WHERE status = "pending"').fetchone()['count']
    }
    
    if search_query:
        all_users = conn.execute('''
            SELECT u.id, u.username, u.email, u.full_name, u.role, u.bio, u.created_at,
                (SELECT COUNT(*) FROM observations WHERE user_id = u.id) as observations_count,
                (SELECT COUNT(*) FROM species WHERE user_id = u.id) as species_count,
                (SELECT COUNT(*) FROM eco_routes WHERE created_by = u.id) as routes_count
            FROM users u
            WHERE u.username LIKE ? OR u.email LIKE ? OR u.full_name LIKE ?
            ORDER BY u.created_at DESC
        ''', (f'%{search_query}%', f'%{search_query}%', f'%{search_query}%')).fetchall()
        
        observations = conn.execute('''
            SELECT o.*, s.name as species_name, u.username as user_name
            FROM observations o
            JOIN species s ON o.species_id = s.id
            JOIN users u ON o.user_id = u.id
            WHERE s.name LIKE ? OR u.username LIKE ? OR o.description LIKE ?
            ORDER BY o.created_at DESC
            LIMIT 50
        ''', (f'%{search_query}%', f'%{search_query}%', f'%{search_query}%')).fetchall()
        
        all_species = conn.execute('''
            SELECT s.*, u.username as creator_name
            FROM species s
            LEFT JOIN users u ON s.user_id = u.id
            WHERE s.name LIKE ? OR s.latin_name LIKE ? OR s.description LIKE ?
            ORDER BY s.created_at DESC
        ''', (f'%{search_query}%', f'%{search_query}%', f'%{search_query}%')).fetchall()
        
        all_routes = conn.execute('''
            SELECT r.*, u.username as creator_name
            FROM eco_routes r
            LEFT JOIN users u ON r.created_by = u.id
            WHERE r.name LIKE ? OR r.description LIKE ?
            ORDER BY r.created_at DESC
        ''', (f'%{search_query}%', f'%{search_query}%')).fetchall()
    else:
        all_users = conn.execute('''
            SELECT u.id, u.username, u.email, u.full_name, u.role, u.bio, u.created_at,
                (SELECT COUNT(*) FROM observations WHERE user_id = u.id) as observations_count,
                (SELECT COUNT(*) FROM species WHERE user_id = u.id) as species_count,
                (SELECT COUNT(*) FROM eco_routes WHERE created_by = u.id) as routes_count
            FROM users u
            ORDER BY u.created_at DESC
        ''').fetchall()
        
        observations = conn.execute('''
            SELECT o.*, s.name as species_name, u.username as user_name
            FROM observations o
            JOIN species s ON o.species_id = s.id
            JOIN users u ON o.user_id = u.id
            ORDER BY o.created_at DESC
            LIMIT 50
        ''').fetchall()
        
        all_species = conn.execute('''
            SELECT s.*, u.username as creator_name
            FROM species s
            LEFT JOIN users u ON s.user_id = u.id
            ORDER BY s.created_at DESC
        ''').fetchall()
        
        all_routes = conn.execute('''
            SELECT r.*, u.username as creator_name
            FROM eco_routes r
            LEFT JOIN users u ON r.created_by = u.id
            ORDER BY r.created_at DESC
        ''').fetchall()
    
    conn.close()
    
    return render_template('admin.html', user=user, stats=stats, 
                         observations=observations, all_species=all_species, 
                         all_routes=all_routes, all_users=all_users,
                         search_query=search_query)


@admin_bp.route('/api/user/<int:user_id>')
@admin_required
def api_user_details(user_id):
    """API для получения детальной информации о пользователе"""
    conn = get_db()
    
    user = conn.execute('''
        SELECT u.id, u.username, u.email, u.full_name, u.role, u.bio, u.created_at,
            (SELECT COUNT(*) FROM observations WHERE user_id = u.id) as observations_count,
            (SELECT COUNT(*) FROM species WHERE user_id = u.id) as species_count,
            (SELECT COUNT(*) FROM eco_routes WHERE created_by = u.id) as routes_count
        FROM users u
        WHERE u.id = ?
    ''', (user_id,)).fetchone()
    
    conn.close()
    
    if not user:
        return jsonify({'error': 'Пользователь не найден'}), 404
    
    return jsonify(dict(user))


@admin_bp.route('/api/support/messages')
@admin_required
def get_support_messages():
    """Получение всех сообщений техподдержки"""
    conn = get_db()
    
    messages = conn.execute('''
        SELECT n.id, n.message, n.created_at, n.status, n.user_id,
               COALESCE(u.username, 'Гость') as sender_name,
               u.email as sender_email
        FROM notifications n
        LEFT JOIN users u ON n.user_id = u.id
        WHERE n.type = 'support'
        ORDER BY n.created_at DESC
    ''').fetchall()
    
    conn.close()
    
    return jsonify([dict(msg) for msg in messages])


@admin_bp.route('/api/support/message/<int:msg_id>')
@admin_required
def get_support_message(msg_id):
    """Получение одного сообщения"""
    conn = get_db()
    
    message = conn.execute('''
        SELECT n.id, n.message, n.created_at, n.status, n.user_id,
               COALESCE(u.username, 'Гость') as sender_name,
               u.email as sender_email
        FROM notifications n
        LEFT JOIN users u ON n.user_id = u.id
        WHERE n.id = ? AND n.type = 'support'
    ''', (msg_id,)).fetchone()
    
    if not message:
        conn.close()
        return jsonify({'error': 'Сообщение не найдено'}), 404
    
    conn.execute('UPDATE notifications SET status = "read" WHERE id = ?', (msg_id,))
    conn.commit()
    conn.close()
    
    return jsonify(dict(message))


@admin_bp.route('/api/support/reply', methods=['POST'])
@admin_required
def reply_to_support():
    """Ответ на сообщение техподдержки"""
    try:
        data = request.get_json()
        original_msg_id = data.get('message_id')
        reply_text = data.get('reply')
        
        if not original_msg_id or not reply_text:
            return jsonify({'success': False, 'error': 'Не указаны данные'}), 400
        
        conn = get_db()
        
        original = conn.execute('''
            SELECT n.message, n.user_id, u.email, u.username
            FROM notifications n
            LEFT JOIN users u ON n.user_id = u.id
            WHERE n.id = ?
        ''', (original_msg_id,)).fetchone()
        
        if not original:
            conn.close()
            return jsonify({'success': False, 'error': 'Сообщение не найдено'}), 404
        
        # Создаем ответ как новое уведомление
        admin = get_current_user()
        
        reply_message = f"📨 ОТВЕТ АДМИНИСТРАТОРА\n━━━━━━━━━━━━━━━━━━━\n👤 Администратор: {admin['username']}\n\n✉️ Ответ:\n{reply_text}\n━━━━━━━━━━━━━━━━━━━\n\n📌 На ваше сообщение:\n{original['message'][:200]}"
        
        conn.execute('''
            INSERT INTO notifications (type, item_id, item_name, user_id, message, status, created_at)
            VALUES (?, ?, ?, ?, ?, 'unread', datetime('now', 'localtime'))
        ''', ('support_reply', original_msg_id, f'Ответ от администратора', original['user_id'], reply_message))
        
        conn.commit()
        conn.close()
        
        return jsonify({'success': True, 'message': 'Ответ отправлен'})
        
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@admin_bp.route('/admin/user/delete/<int:user_id>', methods=['POST'])
@admin_required
def delete_user(user_id):
    current_admin = get_current_user()
    
    if current_admin['id'] == user_id:
        return jsonify({'error': 'Нельзя удалить свой собственный аккаунт'}), 400
    
    conn = get_db()
    user = conn.execute('SELECT username, role FROM users WHERE id = ?', (user_id,)).fetchone()
    
    if not user:
        conn.close()
        return jsonify({'error': 'Пользователь не найден'}), 404
    
    if user['role'] == 'admin':
        conn.close()
        return jsonify({'error': 'Нельзя удалить другого администратора'}), 400
    
    try:
        conn.execute('DELETE FROM observations WHERE user_id = ?', (user_id,))
        conn.execute('DELETE FROM eco_routes WHERE created_by = ?', (user_id,))
        conn.execute('DELETE FROM species WHERE user_id = ?', (user_id,))
        conn.execute('DELETE FROM users WHERE id = ?', (user_id,))
        conn.commit()
        conn.close()
        return jsonify({'success': True})
    except Exception as e:
        conn.close()
        return jsonify({'error': str(e)}), 500