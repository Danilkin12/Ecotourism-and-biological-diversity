# species.py - управление каталогом видов
from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from ..models.database import get_db
from ..utils.decorators import login_required, get_current_user, researcher_required, admin_required
from .notifications import create_notification
from ..achievements import add_xp, check_and_award_achievements

species_bp = Blueprint('species', __name__)


@species_bp.route('/species')
def species_list():
    """Страница со списком всех одобренных видов"""
    user = get_current_user()
    conn = get_db()
    species = conn.execute('SELECT * FROM species WHERE status = "одобрено" ORDER BY name').fetchall()
    conn.close()
    return render_template('species.html', user=user, species=species)


@species_bp.route('/species/pending')
@admin_required
def pending_species():
    """Страница с видами на модерации (только для админа)"""
    user = get_current_user()
    conn = get_db()
    
    species = conn.execute('''
        SELECT s.*, u.username 
        FROM species s
        JOIN users u ON s.user_id = u.id
        WHERE s.status = 'на проверке'
        ORDER BY s.created_at DESC
    ''').fetchall()
    
    conn.close()
    return render_template('pending_species.html', user=user, species=species)


@species_bp.route('/species/<int:species_id>')
def species_detail(species_id):
    """Детальная страница вида с наблюдениями"""
    user = get_current_user()
    conn = get_db()
    species = conn.execute('SELECT * FROM species WHERE id = ?', (species_id,)).fetchone()
    
    if not species:
        conn.close()
        flash('Вид не найден', 'danger')
        return redirect(url_for('species.species_list'))
    
    # Наблюдения этого вида
    observations = conn.execute('''
        SELECT o.*, u.username, u.id as user_id
        FROM observations o
        JOIN users u ON o.user_id = u.id
        WHERE o.species_id = ?
        ORDER BY o.observation_date DESC
        LIMIT 20
    ''', (species_id,)).fetchall()
    
    conn.close()
    return render_template('species_detail.html', user=user, species=species, observations=observations)


@species_bp.route('/species/add', methods=['GET', 'POST'])
@researcher_required
def add_species():
    """Добавление нового вида (только для исследователей и админов)"""
    user = get_current_user()
    
    if request.method == 'POST':
        name = request.form['name']
        latin_name = request.form.get('latin_name', '')
        category = request.form['category']
        description = request.form.get('description', '')
        conservation_status = request.form.get('conservation_status', 'Не указан')
        
        conn = get_db()
        try:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO species (name, latin_name, category, description, conservation_status, user_id, status)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (name, latin_name, category, description, conservation_status, user['id'], 'на проверке'))
            
            species_id = cursor.lastrowid
            conn.commit()
            
            # Уведомление админу о новом виде
            create_notification(
                type='species',
                item_id=species_id,
                item_name=name,
                user_id=user['id'],
                message=f'Исследователь {user["username"]} предложил новый вид: {name}'
            )
            
            # Начисляем опыт
            add_xp(user['id'], 20, 'добавление нового вида')
            check_and_award_achievements(user['id'])
            
            flash(f'Вид "{name}" отправлен на модерацию! +20 XP', 'success')
        except Exception as e:
            flash(f'Ошибка: {str(e)}', 'danger')
        finally:
            conn.close()
        
        return redirect(url_for('species.species_list'))
    
    return render_template('add_species.html', user=user)


@species_bp.route('/species/approve/<int:species_id>')
@admin_required
def approve_species(species_id):
    """Одобрение вида и начисление бонуса автору"""
    conn = get_db()
    
    species = conn.execute('SELECT name, user_id FROM species WHERE id = ?', (species_id,)).fetchone()
    
    conn.execute('UPDATE species SET status = "одобрено" WHERE id = ?', (species_id,))
    conn.commit()
    
    if species and species['user_id']:
        add_xp(species['user_id'], 30, f'одобрение вида "{species["name"]}"')
        check_and_award_achievements(species['user_id'])
    
    conn.close()
    flash(f'Вид "{species["name"]}" одобрен! Автор получил +30 XP', 'success')
    return redirect(url_for('notifications.admin_notifications'))


@species_bp.route('/species/reject/<int:species_id>')
@admin_required
def reject_species(species_id):
    """Отклонение вида (удаление)"""
    conn = get_db()
    species = conn.execute('SELECT name FROM species WHERE id = ?', (species_id,)).fetchone()
    conn.execute('DELETE FROM species WHERE id = ?', (species_id,))
    conn.commit()
    conn.close()
    flash(f'Вид "{species["name"]}" отклонён', 'warning')
    return redirect(url_for('notifications.admin_notifications'))


@species_bp.route('/species/delete/<int:species_id>', methods=['POST'])
@login_required
def delete_species(species_id):
    """Удаление вида (админ может всё, исследователь - только свой неодобренный)"""
    user = get_current_user()
    conn = get_db()
    
    species = conn.execute('SELECT * FROM species WHERE id = ?', (species_id,)).fetchone()
    
    if not species:
        conn.close()
        flash('Вид не найден', 'danger')
        return redirect(url_for('species.species_list'))
    
    # Админ удаляет любые виды
    if user['role'] == 'admin':
        conn.execute('DELETE FROM observations WHERE species_id = ?', (species_id,))
        conn.execute('DELETE FROM species WHERE id = ?', (species_id,))
        conn.commit()
        conn.close()
        flash('Вид и все связанные наблюдения удалены администратором', 'success')
        return redirect(url_for('admin.admin_panel'))
    
    # Исследователь удаляет только свои неодобренные виды
    elif user['role'] == 'researcher' and species['user_id'] == user['id']:
        if species['status'] == 'одобрено':
            conn.close()
            flash('Нельзя удалить одобренный вид. Обратитесь к администратору', 'danger')
            return redirect(url_for('species.species_list'))
        
        conn.execute('DELETE FROM species WHERE id = ?', (species_id,))
        conn.commit()
        conn.close()
        flash('Ваш вид удалён', 'success')
        return redirect(url_for('species.species_list'))
    
    else:
        conn.close()
        flash('У вас нет прав для удаления этого вида', 'danger')
        return redirect(url_for('species.species_list'))