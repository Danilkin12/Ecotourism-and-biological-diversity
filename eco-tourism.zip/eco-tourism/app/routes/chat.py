from flask import Blueprint, jsonify, request
from ..models.database import get_db
from ..utils.decorators import login_required, admin_required, get_current_user

chat_bp = Blueprint('chat', __name__)


@chat_bp.route('/api/chat/send', methods=['POST'])
@login_required
def send_message():
    """Отправка сообщения в поддержку"""
    try:
        user = get_current_user()
        data = request.get_json()
        message = data.get('message')
        
        if not message or not message.strip():
            return jsonify({'success': False, 'error': 'Сообщение не может быть пустым'}), 400
        
        conn = get_db()
        admin = conn.execute('SELECT id FROM users WHERE role = "admin" LIMIT 1').fetchone()
        
        if not admin:
            conn.close()
            return jsonify({'success': False, 'error': 'Администратор не найден'}), 404
        
        conn.execute('''
            INSERT INTO chat_messages (sender_id, receiver_id, message, is_read, created_at)
            VALUES (?, ?, ?, 0, datetime("now", "localtime"))
        ''', (user['id'], admin['id'], message.strip()))
        
        conn.commit()
        conn.close()
        
        return jsonify({'success': True, 'message': 'Сообщение отправлено'})
        
    except Exception as e:
        print(f"❌ Ошибка отправки: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@chat_bp.route('/api/chat/messages')
@login_required
def get_messages():
    """Получение сообщений для пользователя"""
    try:
        user = get_current_user()
        conn = get_db()
        
        admin = conn.execute('SELECT id FROM users WHERE role = "admin" LIMIT 1').fetchone()
        
        if not admin:
            conn.close()
            return jsonify({'messages': []})
        
        messages = conn.execute('''
            SELECT 
                cm.id,
                cm.message,
                cm.created_at,
                cm.sender_id,
                u.username as sender_name,
                cm.is_read
            FROM chat_messages cm
            JOIN users u ON cm.sender_id = u.id
            WHERE (cm.sender_id = ? AND cm.receiver_id = ?) 
               OR (cm.sender_id = ? AND cm.receiver_id = ?)
            ORDER BY cm.created_at ASC
        ''', (user['id'], admin['id'], admin['id'], user['id'])).fetchall()
        
        conn.execute('''
            UPDATE chat_messages SET is_read = 1 
            WHERE sender_id = ? AND receiver_id = ? AND is_read = 0
        ''', (admin['id'], user['id']))
        conn.commit()
        conn.close()
        
        result = []
        for msg in messages:
            result.append({
                'id': msg['id'],
                'message': msg['message'],
                'created_at': msg['created_at'],
                'sender_id': msg['sender_id'],
                'sender_name': msg['sender_name'],
                'is_read': msg['is_read'],
                'is_mine': msg['sender_id'] == user['id']
            })
        
        return jsonify({'messages': result})
        
    except Exception as e:
        print(f"❌ Ошибка получения сообщений: {e}")
        return jsonify({'messages': [], 'error': str(e)}), 500


@chat_bp.route('/api/chat/unread-count')
@login_required
def get_unread_count():
    """Получение количества непрочитанных сообщений"""
    try:
        user = get_current_user()
        conn = get_db()
        
        count = conn.execute('''
            SELECT COUNT(*) as cnt
            FROM chat_messages
            WHERE receiver_id = ? AND is_read = 0
        ''', (user['id'],)).fetchone()['cnt']
        
        conn.close()
        return jsonify({'count': count})
        
    except Exception as e:
        return jsonify({'count': 0})


@chat_bp.route('/api/admin/chat/users')
@admin_required
def get_chat_users():
    """Получение списка пользователей для админа"""
    try:
        admin = get_current_user()
        conn = get_db()
        
        users = conn.execute('''
            SELECT DISTINCT 
                u.id,
                u.username,
                u.full_name,
                u.email,
                u.role,
                (SELECT COUNT(*) FROM chat_messages 
                 WHERE sender_id = u.id AND receiver_id = ? AND is_read = 0) as unread_count,
                (SELECT message FROM chat_messages 
                 WHERE (sender_id = u.id AND receiver_id = ?) OR (sender_id = ? AND receiver_id = u.id)
                 ORDER BY created_at DESC LIMIT 1) as last_message,
                (SELECT created_at FROM chat_messages 
                 WHERE (sender_id = u.id AND receiver_id = ?) OR (sender_id = ? AND receiver_id = u.id)
                 ORDER BY created_at DESC LIMIT 1) as last_message_time
            FROM users u
            JOIN chat_messages cm ON (cm.sender_id = u.id OR cm.receiver_id = u.id)
            WHERE u.role != 'admin' AND u.id != ?
            GROUP BY u.id
            ORDER BY last_message_time DESC
        ''', (admin['id'], admin['id'], admin['id'], admin['id'], admin['id'], admin['id'])).fetchall()
        
        conn.close()
        
        result = []
        for user in users:
            result.append({
                'id': user['id'],
                'username': user['username'],
                'full_name': user['full_name'],
                'email': user['email'],
                'unread_count': user['unread_count'] or 0,
                'last_message': user['last_message'],
                'last_message_time': user['last_message_time']
            })
        
        return jsonify({'users': result})
        
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        return jsonify({'users': [], 'error': str(e)}), 500


@chat_bp.route('/api/admin/chat/messages/<int:user_id>')
@admin_required
def get_admin_messages(user_id):
    """Получение сообщений с конкретным пользователем для админа"""
    try:
        admin = get_current_user()
        conn = get_db()
        
        messages = conn.execute('''
            SELECT 
                cm.id,
                cm.message,
                cm.created_at,
                cm.sender_id,
                u.username as sender_name,
                cm.is_read
            FROM chat_messages cm
            JOIN users u ON cm.sender_id = u.id
            WHERE (cm.sender_id = ? AND cm.receiver_id = ?) 
               OR (cm.sender_id = ? AND cm.receiver_id = ?)
            ORDER BY cm.created_at ASC
        ''', (admin['id'], user_id, user_id, admin['id'])).fetchall()
        
        conn.execute('''
            UPDATE chat_messages SET is_read = 1 
            WHERE sender_id = ? AND receiver_id = ? AND is_read = 0
        ''', (user_id, admin['id']))
        conn.commit()
        conn.close()
        
        result = []
        for msg in messages:
            result.append({
                'id': msg['id'],
                'message': msg['message'],
                'created_at': msg['created_at'],
                'sender_id': msg['sender_id'],
                'sender_name': msg['sender_name'],
                'is_mine': msg['sender_id'] == admin['id']
            })
        
        return jsonify({'messages': result, 'user_id': user_id})
        
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        return jsonify({'messages': [], 'error': str(e)}), 500


@chat_bp.route('/api/admin/chat/send', methods=['POST'])
@admin_required
def admin_send_message():
    """Отправка сообщения от админа пользователю"""
    try:
        admin = get_current_user()
        data = request.get_json()
        user_id = data.get('user_id')
        message = data.get('message')
        
        if not message or not message.strip():
            return jsonify({'success': False, 'error': 'Сообщение не может быть пустым'}), 400
        
        if not user_id:
            return jsonify({'success': False, 'error': 'Не указан получатель'}), 400
        
        conn = get_db()
        conn.execute('''
            INSERT INTO chat_messages (sender_id, receiver_id, message, is_read, created_at)
            VALUES (?, ?, ?, 0, datetime("now", "localtime"))
        ''', (admin['id'], user_id, message.strip()))
        
        conn.commit()
        conn.close()
        
        return jsonify({'success': True, 'message': 'Сообщение отправлено'})
        
    except Exception as e:
        print(f"❌ Ошибка отправки: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500