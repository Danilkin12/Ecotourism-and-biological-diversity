from flask import Blueprint, render_template, send_from_directory, current_app, abort, request, flash, redirect, url_for, session, make_response, jsonify
from app.models.database import get_db
from app.utils.decorators import get_current_user, login_required
import os
from werkzeug.utils import secure_filename
from datetime import datetime
from PIL import Image

main_bp = Blueprint('main', __name__)

# Разрешённые форматы файлов для загрузки
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}


def allowed_file(filename):
    """Проверяет, разрешён ли формат загружаемого файла"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


@main_bp.route('/')
def index():
    """Главная страница с последними наблюдениями и видами"""
    user = get_current_user()
    conn = get_db()
    
    # Получаем 6 последних наблюдений
    observations = conn.execute('''
        SELECT o.*, s.name as species_name, u.username as user_name, u.id as user_id, u.avatar as user_avatar
        FROM observations o
        JOIN species s ON o.species_id = s.id
        JOIN users u ON o.user_id = u.id
        ORDER BY o.observation_date DESC
        LIMIT 6
    ''').fetchall()
    
    # Получаем 6 последних одобренных видов
    species = conn.execute('SELECT * FROM species WHERE status = "одобрено" ORDER BY name LIMIT 6').fetchall()
    
    conn.close()
    return render_template('index.html', user=user, observations=observations, species=species)


@main_bp.route('/user/<int:user_id>')
def user_profile(user_id):
    """Публичный профиль пользователя - доступен всем посетителям"""
    current_user = get_current_user()
    conn = get_db()
    
    # Получаем данные пользователя
    user = conn.execute('SELECT id, username, email, full_name, role, bio, avatar, xp, level, created_at FROM users WHERE id = ?', (user_id,)).fetchone()
    
    if not user:
        conn.close()
        flash('Пользователь не найден', 'danger')
        return redirect(url_for('main.index'))
    
    # Статистика активности пользователя
    stats = conn.execute('''
        SELECT 
            COUNT(DISTINCT o.id) as total_observations,
            COUNT(DISTINCT s.id) as total_species,
            COUNT(DISTINCT r.id) as total_routes,
            (SELECT COUNT(*) FROM user_achievements WHERE user_id = ?) as achievements_earned,
            (SELECT COUNT(*) FROM achievements) as achievements_total
        FROM users u
        LEFT JOIN observations o ON u.id = o.user_id
        LEFT JOIN species s ON u.id = s.user_id
        LEFT JOIN eco_routes r ON u.id = r.created_by
        WHERE u.id = ?
    ''', (user_id, user_id)).fetchone()
    
    # Последние 10 наблюдений пользователя
    recent_observations = conn.execute('''
        SELECT o.id, o.description, o.observation_date, o.photo_url, o.latitude, o.longitude, o.count, s.name as species_name, s.id as species_id
        FROM observations o
        JOIN species s ON o.species_id = s.id
        WHERE o.user_id = ?
        ORDER BY o.observation_date DESC
        LIMIT 10
    ''', (user_id,)).fetchall()
    
    # Последние 10 маршрутов пользователя
    recent_routes = conn.execute('''
        SELECT id, name, description, difficulty, length_km, duration_hours, created_at, status
        FROM eco_routes
        WHERE created_by = ?
        ORDER BY created_at DESC
        LIMIT 10
    ''', (user_id,)).fetchall()
    
    conn.close()
    return render_template('user_profile.html', 
                         user=current_user, 
                         profile_user=user, 
                         stats=stats,
                         recent_observations=recent_observations,
                         recent_routes=recent_routes)


@main_bp.route('/profile')
@login_required
def profile():
    """Личный профиль пользователя с настройками"""
    user = get_current_user()
    conn = get_db()
    
    # Статистика наблюдений пользователя
    stats = conn.execute('''
        SELECT 
            COUNT(*) as total_observations,
            COUNT(DISTINCT species_id) as unique_species,
            SUM(CASE WHEN status = 'одобрено' THEN 1 ELSE 0 END) as approved_count,
            SUM(CASE WHEN status = 'на проверке' THEN 1 ELSE 0 END) as pending_count
        FROM observations 
        WHERE user_id = ?
    ''', (user['id'],)).fetchone()
    
    # Все наблюдения пользователя (без ограничений)
    recent_observations = conn.execute('''
        SELECT o.*, s.name as species_name, s.category
        FROM observations o
        JOIN species s ON o.species_id = s.id
        WHERE o.user_id = ?
        ORDER BY o.observation_date DESC
    ''', (user['id'],)).fetchall()
    
    # Все маршруты пользователя
    user_routes = conn.execute('''
        SELECT * FROM eco_routes 
        WHERE created_by = ?
        ORDER BY created_at DESC
    ''', (user['id'],)).fetchall()
    
    # Статистика достижений
    achievements_stats = conn.execute('''
        SELECT 
            (SELECT COUNT(*) FROM achievements) as total,
            (SELECT COUNT(*) FROM user_achievements WHERE user_id = ?) as earned
    ''', (user['id'],)).fetchone()
    
    conn.close()
    
    return render_template('profile.html', 
                         user=user, 
                         stats=stats, 
                         recent_observations=recent_observations, 
                         user_routes=user_routes,
                         achievements_stats=achievements_stats)


@main_bp.route('/profile/update', methods=['POST'])
@login_required
def update_profile():
    """Обновление информации в профиле"""
    user = get_current_user()
    conn = get_db()
    
    full_name = request.form.get('full_name', '')
    bio = request.form.get('bio', '')
    
    try:
        conn.execute('''
            UPDATE users 
            SET full_name = ?, bio = ? 
            WHERE id = ?
        ''', (full_name, bio, user['id']))
        conn.commit()
        flash('Профиль успешно обновлён!', 'success')
    except Exception as e:
        flash(f'Ошибка: {str(e)}', 'danger')
    finally:
        conn.close()
    
    return redirect(url_for('main.profile'))


@main_bp.route('/profile/upload-avatar', methods=['POST'])
@login_required
def upload_avatar():
    """Загрузка аватара пользователя"""
    user = get_current_user()
    
    if 'avatar' not in request.files:
        flash('Файл не выбран', 'danger')
        return redirect(url_for('main.profile'))
    
    file = request.files['avatar']
    if file.filename == '':
        flash('Файл не выбран', 'danger')
        return redirect(url_for('main.profile'))
    
    if file and allowed_file(file.filename):
        ext = file.filename.rsplit('.', 1)[1].lower()
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"avatar_{user['id']}_{timestamp}.{ext}"
        
        avatar_folder = os.path.join(current_app.config['UPLOAD_FOLDER'], 'avatars')
        os.makedirs(avatar_folder, exist_ok=True)
        
        filepath = os.path.join(avatar_folder, filename)
        file.save(filepath)
        
        conn = get_db()
        conn.execute('UPDATE users SET avatar = ? WHERE id = ?', (filename, user['id']))
        conn.commit()
        conn.close()
        
        flash('Аватар успешно загружен!', 'success')
    else:
        flash('Недопустимый формат файла. Используйте JPG, PNG или GIF', 'danger')
    
    return redirect(url_for('main.profile'))


@main_bp.route('/profile/delete', methods=['POST'])
@login_required
def delete_account():
    """Полное удаление аккаунта и всех связанных данных"""
    user = get_current_user()
    
    if user['role'] == 'admin':
        flash('Администратор не может удалить свой аккаунт', 'danger')
        return redirect(url_for('main.profile'))
    
    conn = get_db()
    
    try:
        # Удаляем наблюдения
        conn.execute('DELETE FROM observations WHERE user_id = ?', (user['id'],))
        
        # Удаляем маршруты и их точки
        routes = conn.execute('SELECT id FROM eco_routes WHERE created_by = ?', (user['id'],)).fetchall()
        for route in routes:
            conn.execute('DELETE FROM route_points WHERE route_id = ?', (route['id'],))
        conn.execute('DELETE FROM eco_routes WHERE created_by = ?', (user['id'],))
        
        # Удаляем виды
        conn.execute('DELETE FROM species WHERE user_id = ?', (user['id'],))
        
        # Удаляем пользователя
        conn.execute('DELETE FROM users WHERE id = ?', (user['id'],))
        conn.commit()
        
        # Очищаем куки
        response = make_response(redirect(url_for('main.index')))
        response.delete_cookie('user_id')
        response.delete_cookie('username')
        response.delete_cookie('role')
        
        flash('Ваш аккаунт и все данные успешно удалены', 'success')
        return response
        
    except Exception as e:
        conn.rollback()
        flash(f'Ошибка при удалении аккаунта: {str(e)}', 'danger')
        return redirect(url_for('main.profile'))
    finally:
        conn.close()


@main_bp.route('/uploads/<filename>')
def uploaded_file(filename):
    """Отдача загруженных файлов (фото наблюдений)"""
    try:
        upload_folder = current_app.config['UPLOAD_FOLDER']
        
        # Проверяем в папке аватаров
        avatar_path = os.path.join(upload_folder, 'avatars', filename)
        if os.path.exists(avatar_path):
            return send_from_directory(os.path.join(upload_folder, 'avatars'), filename)
        
        # Проверяем в корне папки загрузок
        file_path = os.path.join(upload_folder, filename)
        if os.path.exists(file_path):
            return send_from_directory(upload_folder, filename)
        
        return "Файл не найден", 404
    except Exception as e:
        return str(e), 500


@main_bp.route('/uploads/thumb_<filename>')
def uploaded_thumb(filename):
    """Отдача миниатюр фото"""
    return uploaded_file(f"thumb_{filename}")


@main_bp.route('/uploads/avatars/<filename>')
def uploaded_avatar(filename):
    """Отдача аватаров пользователей"""
    try:
        upload_folder = current_app.config['UPLOAD_FOLDER']
        avatar_folder = os.path.join(upload_folder, 'avatars')
        filepath = os.path.join(avatar_folder, filename)
        if os.path.exists(filepath):
            return send_from_directory(avatar_folder, filename)
        else:
            return send_from_directory('static', 'default-avatar.png')
    except:
        return send_from_directory('static', 'default-avatar.png'), 200


@main_bp.route('/set-language')
def set_language():
    """Переключение языка интерфейса"""
    lang = request.args.get('lang', 'ru')
    session['lang'] = lang
    return redirect(request.referrer or url_for('main.index'))


# ========== СТРАНИЦЫ ==========

@main_bp.route('/about')
def about():
    """Страница 'О проекте'"""
    user = get_current_user()
    return render_template('about.html', user=user)


@main_bp.route('/contacts')
def contacts():
    """Страница контактов"""
    user = get_current_user()
    return render_template('contacts.html', user=user)


@main_bp.route('/help')
def help():
    """Страница помощи и часто задаваемые вопросы"""
    user = get_current_user()
    return render_template('help.html', user=user)


@main_bp.route('/docs')
def docs():
    """Страница документации"""
    user = get_current_user()
    return render_template('docs.html', user=user)


@main_bp.route('/api/docs')
def api_docs():
    """Страница документации по API"""
    user = get_current_user()
    return render_template('api_docs.html', user=user)


# ========== API ДЛЯ ПОИСКА ==========

@main_bp.route('/api/search')
def api_search():
    """Поиск по наблюдениям, видам и маршрутам"""
    query = request.args.get('q', '')
    
    if len(query) < 2:
        return jsonify({'results': []})
    
    conn = get_db()
    results = []
    
    try:
        # Поиск по наблюдениям
        observations = conn.execute('''
            SELECT o.id, s.name, o.description, u.username, u.id as user_id
            FROM observations o
            JOIN species s ON o.species_id = s.id
            JOIN users u ON o.user_id = u.id
            WHERE s.name LIKE ? OR o.description LIKE ?
            LIMIT 5
        ''', (f'%{query}%', f'%{query}%')).fetchall()
        
        for obs in observations:
            results.append({
                'type': 'observation',
                'type_ru': 'Наблюдение',
                'title': obs['name'],
                'description': f"👤 {obs['username']} • {obs['description'][:50] if obs['description'] else 'Нет описания'}",
                'url': f"/observations/map"
            })
        
        # Поиск по видам
        species = conn.execute('''
            SELECT id, name, latin_name, category
            FROM species
            WHERE name LIKE ? OR latin_name LIKE ?
            LIMIT 5
        ''', (f'%{query}%', f'%{query}%')).fetchall()
        
        for s in species:
            results.append({
                'type': 'species',
                'type_ru': 'Вид',
                'title': s['name'],
                'description': f"({s['latin_name'] or 'нет лат. названия'}) • Категория: {s['category']}",
                'url': f"/species/{s['id']}"
            })
        
        # Поиск по маршрутам
        routes = conn.execute('''
            SELECT id, name, description, difficulty
            FROM eco_routes
            WHERE name LIKE ? OR description LIKE ?
            LIMIT 5
        ''', (f'%{query}%', f'%{query}%')).fetchall()
        
        for r in routes:
            results.append({
                'type': 'route',
                'type_ru': 'Маршрут',
                'title': r['name'],
                'description': f"Сложность: {r['difficulty'] or 'не указана'} • {r['description'][:50] if r['description'] else ''}",
                'url': f"/eco-route/{r['id']}"
            })
        
    except Exception as e:
        return jsonify({'results': [], 'error': str(e)}), 500
    finally:
        conn.close()
    
    return jsonify({'results': results})


# ========== ТЕХПОДДЕРЖКА ==========

@main_bp.route('/api/send-support', methods=['POST'])
def send_support():
    """Отправка сообщения в техподдержку"""
    try:
        data = request.get_json()
        name = data.get('name')
        email = data.get('email')
        message = data.get('message')
        
        if not name or not message:
            return jsonify({'success': False, 'error': 'Имя и сообщение обязательны'}), 400
        
        conn = get_db()
        
        # Находим всех администраторов
        admins = conn.execute('SELECT id FROM users WHERE role = "admin"').fetchall()
        
        notification_message = f"СООБЩЕНИЕ В ПОДДЕРЖКУ\n━━━━━━━━━━━━━━━━━━━\nОт: {name}\nEmail: {email or 'не указан'}\n\nСообщение:\n{message}"
        
        # Создаём уведомление для каждого админа
        for admin in admins:
            conn.execute('''
                INSERT INTO notifications (type, item_id, item_name, user_id, message, status, created_at)
                VALUES ('support', 0, f'Сообщение от {name}', ?, ?, 'unread', datetime("now", "localtime"))
            ''', (admin['id'], notification_message))
        
        conn.commit()
        conn.close()
        
        return jsonify({'success': True, 'message': 'Сообщение отправлено администратору'})
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500