from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from ..models.database import get_db
from ..utils.decorators import login_required, get_current_user, admin_required
from .notifications import create_notification
from ..achievements import add_xp, check_and_award_achievements

eco_routes_bp = Blueprint('eco_routes', __name__)


@eco_routes_bp.route('/eco-routes')
def eco_routes_list():
    """Список всех одобренных маршрутов с сортировкой"""
    user = get_current_user()
    conn = get_db()
    
    sort = request.args.get('sort', 'newest')
    
    if sort == 'oldest':
        order_by = 'e.created_at ASC'
    else:
        order_by = 'e.created_at DESC'
    
    routes = conn.execute(f'''
        SELECT e.*, u.username as creator_name, u.id as creator_id, u.avatar as creator_avatar,
               (SELECT COUNT(*) FROM route_points WHERE route_id = e.id) as points_count
        FROM eco_routes e
        JOIN users u ON e.created_by = u.id
        WHERE e.status = 'одобрено'
        ORDER BY {order_by}
    ''').fetchall()
    
    conn.close()
    return render_template('eco_routes.html', user=user, routes=routes, current_sort=sort)


@eco_routes_bp.route('/eco-route/<int:route_id>')
def eco_route_detail(route_id):
    user = get_current_user()
    conn = get_db()
    
    route = conn.execute('''
        SELECT e.*, u.username as creator_name, u.full_name, u.id as creator_id, u.avatar as creator_avatar
        FROM eco_routes e
        JOIN users u ON e.created_by = u.id
        WHERE e.id = ?
    ''', (route_id,)).fetchone()
    
    if not route:
        conn.close()
        flash('Маршрут не найден', 'danger')
        return redirect(url_for('eco_routes.eco_routes_list'))
    
    if route['status'] != 'одобрено' and not (user and (user['role'] == 'admin' or user['id'] == route['created_by'])):
        conn.close()
        flash('Маршрут ещё не одобрен', 'warning')
        return redirect(url_for('eco_routes.eco_routes_list'))
    
    route_points = conn.execute('''
        SELECT rp.*, s.name as species_name, s.category
        FROM route_points rp
        LEFT JOIN species s ON rp.species_id = s.id
        WHERE rp.route_id = ?
        ORDER BY rp.order_index
    ''', (route_id,)).fetchall()
    
    conn.close()
    return render_template('eco_route_detail.html', user=user, route=route, route_points=route_points)


@eco_routes_bp.route('/eco-route/create', methods=['GET', 'POST'])
@login_required
def create_eco_route():
    user = get_current_user()
    
    if request.method == 'POST':
        name = request.form['name']
        description = request.form['description']
        difficulty = request.form['difficulty']
        length_km = request.form.get('length_km', 0)
        duration_hours = request.form.get('duration_hours', 0)
        
        if not name or not description or not difficulty:
            flash('Заполните все обязательные поля', 'danger')
            return redirect(url_for('eco_routes.create_eco_route'))
        
        conn = None
        try:
            conn = get_db()
            conn.execute('BEGIN IMMEDIATE')
            
            cursor = conn.cursor()
            
            if user['role'] == 'admin':
                status = 'одобрено'
            else:
                status = 'на проверке'
            
            cursor.execute('''
                INSERT INTO eco_routes (name, description, difficulty, length_km, duration_hours, created_by, status)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (name, description, difficulty, length_km, duration_hours, user['id'], status))
            
            route_id = cursor.lastrowid
            conn.commit()
            conn.close()
            
            add_xp(user['id'], 15, 'создание маршрута')
            check_and_award_achievements(user['id'])
            
            if user['role'] == 'admin':
                flash(f'Маршрут "{name}" создан! +15 XP. Теперь добавьте точки.', 'success')
                return redirect(url_for('eco_routes.add_route_points', route_id=route_id))
            else:
                create_notification(
                    type='route',
                    item_id=route_id,
                    item_name=name,
                    user_id=user['id'],
                    message=f'Исследователь {user["username"]} предложил новый маршрут: {name}'
                )
                flash(f'Маршрут "{name}" отправлен на модерацию! +15 XP', 'success')
                return redirect(url_for('eco_routes.eco_routes_list'))
                
        except Exception as e:
            if conn:
                conn.rollback()
                conn.close()
            flash(f'Ошибка: {str(e)}', 'danger')
            return redirect(url_for('eco_routes.create_eco_route'))
    
    return render_template('create_eco_route.html', user=user)


@eco_routes_bp.route('/eco-route/<int:route_id>/add-points', methods=['GET', 'POST'])
@login_required
def add_route_points(route_id):
    user = get_current_user()
    conn = get_db()
    
    route = conn.execute('SELECT * FROM eco_routes WHERE id = ?', (route_id,)).fetchone()
    
    if not route:
        conn.close()
        flash('Маршрут не найден', 'danger')
        return redirect(url_for('eco_routes.eco_routes_list'))
    
    if route['created_by'] != user['id'] and user['role'] != 'admin':
        conn.close()
        flash('У вас нет прав для редактирования этого маршрута', 'danger')
        return redirect(url_for('eco_routes.eco_route_detail', route_id=route_id))
    
    if request.method == 'POST':
        titles = request.form.getlist('title[]')
        lats = request.form.getlist('lat[]')
        lngs = request.form.getlist('lng[]')
        descriptions = request.form.getlist('description[]')
        species_ids = request.form.getlist('species_id[]')
        
        try:
            conn = get_db()
            conn.execute('BEGIN IMMEDIATE')
            
            conn.execute('DELETE FROM route_points WHERE route_id = ?', (route_id,))
            
            for i in range(len(titles)):
                if titles[i] and lats[i] and lngs[i]:
                    species_id = species_ids[i] if i < len(species_ids) and species_ids[i] else None
                    conn.execute('''
                        INSERT INTO route_points (route_id, latitude, longitude, order_index, title, description, species_id)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    ''', (route_id, float(lats[i]), float(lngs[i]), i+1, titles[i], descriptions[i], species_id))
            
            conn.commit()
            conn.close()
            
            points_count = len([t for t in titles if t])
            if points_count > 0:
                xp_for_points = points_count * 5
                add_xp(user['id'], xp_for_points, f'добавление {points_count} точек маршрута')
                check_and_award_achievements(user['id'])
                flash(f'Точки маршрута добавлены! +{xp_for_points} XP', 'success')
            else:
                flash('Точки маршрута добавлены!', 'success')
            
            return redirect(url_for('eco_routes.eco_route_detail', route_id=route_id))
            
        except Exception as e:
            if conn:
                conn.rollback()
                conn.close()
            flash(f'Ошибка: {str(e)}', 'danger')
            return redirect(url_for('eco_routes.add_route_points', route_id=route_id))
    
    species = conn.execute('SELECT * FROM species WHERE status = "одобрено" ORDER BY name').fetchall()
    existing_points = conn.execute('SELECT * FROM route_points WHERE route_id = ? ORDER BY order_index', (route_id,)).fetchall()
    conn.close()
    
    return render_template('add_route_points.html', user=user, route=route, species=species, existing_points=existing_points)


@eco_routes_bp.route('/eco-routes/pending')
@admin_required
def pending_routes():
    user = get_current_user()
    conn = get_db()
    
    routes = conn.execute('''
        SELECT e.*, u.username as creator_name, u.full_name, u.id as creator_id
        FROM eco_routes e
        JOIN users u ON e.created_by = u.id
        WHERE e.status = 'на проверке'
        ORDER BY e.created_at DESC
    ''').fetchall()
    
    conn.close()
    return render_template('pending_routes.html', user=user, routes=routes)


@eco_routes_bp.route('/eco-route/approve/<int:route_id>')
@admin_required
def approve_route(route_id):
    conn = get_db()
    route = conn.execute('SELECT name, created_by FROM eco_routes WHERE id = ?', (route_id,)).fetchone()
    
    if route:
        conn.execute('UPDATE eco_routes SET status = "одобрено" WHERE id = ?', (route_id,))
        conn.commit()
        
        if route['created_by']:
            add_xp(route['created_by'], 25, f'одобрение маршрута "{route["name"]}"')
            check_and_award_achievements(route['created_by'])
        
        flash(f'Маршрут "{route["name"]}" одобрен! Автор получил +25 XP', 'success')
    else:
        flash('Маршрут не найден', 'danger')
    
    conn.close()
    return redirect(url_for('notifications.admin_notifications'))


@eco_routes_bp.route('/eco-route/reject/<int:route_id>')
@admin_required
def reject_route(route_id):
    conn = get_db()
    route = conn.execute('SELECT name FROM eco_routes WHERE id = ?', (route_id,)).fetchone()
    
    if route:
        conn.execute('UPDATE eco_routes SET status = "отклонён" WHERE id = ?', (route_id,))
        conn.commit()
        flash(f'Маршрут "{route["name"]}" отклонён', 'warning')
    else:
        flash('Маршрут не найден', 'danger')
    
    conn.close()
    return redirect(url_for('notifications.admin_notifications'))


@eco_routes_bp.route('/eco-route/delete/<int:route_id>', methods=['POST'])
@login_required
def delete_route(route_id):
    user = get_current_user()
    conn = get_db()
    
    route = conn.execute('SELECT * FROM eco_routes WHERE id = ?', (route_id,)).fetchone()
    
    if not route:
        conn.close()
        flash('Маршрут не найден', 'danger')
        return redirect(url_for('eco_routes.eco_routes_list'))
    
    if user['role'] == 'admin':
        conn.execute('DELETE FROM route_points WHERE route_id = ?', (route_id,))
        conn.execute('DELETE FROM eco_routes WHERE id = ?', (route_id,))
        conn.commit()
        conn.close()
        flash('Маршрут удалён администратором', 'success')
        return redirect(url_for('admin.admin_panel'))
    
    elif user['role'] == 'researcher' and route['created_by'] == user['id']:
        if route['status'] == 'одобрено':
            conn.close()
            flash('Нельзя удалить одобренный маршрут. Обратитесь к администратору', 'danger')
            return redirect(url_for('eco_routes.eco_routes_list'))
        
        conn.execute('DELETE FROM route_points WHERE route_id = ?', (route_id,))
        conn.execute('DELETE FROM eco_routes WHERE id = ?', (route_id,))
        conn.commit()
        conn.close()
        flash('Ваш маршрут удалён', 'success')
        return redirect(url_for('eco_routes.eco_routes_list'))
    
    else:
        conn.close()
        flash('У вас нет прав для удаления этого маршрута', 'danger')
        return redirect(url_for('eco_routes.eco_routes_list'))


@eco_routes_bp.route('/api/eco-routes')
def api_eco_routes():
    conn = get_db()
    routes = conn.execute('''
        SELECT id, name, description, difficulty, length_km, duration_hours, created_by, status
        FROM eco_routes 
        WHERE status = 'одобрено'
        ORDER BY created_at DESC
    ''').fetchall()
    conn.close()
    
    routes_list = []
    for route in routes:
        routes_list.append({
            'id': route['id'],
            'name': route['name'],
            'description': route['description'],
            'difficulty': route['difficulty'],
            'length_km': route['length_km'],
            'duration_hours': route['duration_hours'],
            'status': route['status']
        })
    
    return jsonify(routes_list)


@eco_routes_bp.route('/api/eco-route/<int:route_id>/geojson')
def api_eco_route_geojson(route_id):
    conn = get_db()
    
    route = conn.execute('SELECT * FROM eco_routes WHERE id = ?', (route_id,)).fetchone()
    
    if not route:
        conn.close()
        return jsonify({"error": "Маршрут не найден"}), 404
    
    user = get_current_user()
    if route['status'] != 'одобрено' and not (user and (user['role'] == 'admin' or user['id'] == route['created_by'])):
        conn.close()
        return jsonify({"error": "Маршрут недоступен"}), 403
    
    points = conn.execute('''
        SELECT latitude, longitude, order_index, title, description
        FROM route_points
        WHERE route_id = ?
        ORDER BY order_index
    ''', (route_id,)).fetchall()
    
    conn.close()
    
    coordinates = []
    if points:
        coordinates = [[float(p['longitude']), float(p['latitude'])] for p in points]
    else:
        coordinates = [[37.6173, 55.7558], [37.6273, 55.7658], [37.6373, 55.7758]]
    
    geojson = {
        "type": "FeatureCollection",
        "features": [{
            "type": "Feature",
            "properties": {
                "name": route['name'],
                "description": route['description'],
                "difficulty": route['difficulty'],
                "length_km": route['length_km'],
                "duration_hours": route['duration_hours'],
                "status": route['status']
            },
            "geometry": {
                "type": "LineString",
                "coordinates": coordinates
            }
        }]
    }
    
    return jsonify(geojson)


@eco_routes_bp.route('/api/eco-routes/stats')
def api_eco_routes_stats():
    conn = get_db()
    
    total = conn.execute('SELECT COUNT(*) as count FROM eco_routes WHERE status = "одобрено"').fetchone()['count']
    by_difficulty = conn.execute('''
        SELECT difficulty, COUNT(*) as count 
        FROM eco_routes 
        WHERE status = "одобрено"
        GROUP BY difficulty
    ''').fetchall()
    
    conn.close()
    
    stats = {
        'total': total,
        'by_difficulty': {row['difficulty']: row['count'] for row in by_difficulty}
    }
    
    return jsonify(stats)