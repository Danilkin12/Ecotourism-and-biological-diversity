# observations.py - управление наблюдениями пользователей
# Содержит все функции для работы с наблюдениями: добавление, редактирование, удаление, просмотр, сортировка
from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from ..models.database import get_db
from ..services.file_service import save_photo
from ..utils.decorators import login_required, get_current_user
from ..achievements import add_xp, check_and_award_achievements

observations_bp = Blueprint('observations', __name__)


# ========== ОСНОВНЫЕ СТРАНИЦЫ ==========

@observations_bp.route('/observations/map')
def observations_map():
    """Страница с картой всех наблюдений"""
    user = get_current_user()
    return render_template('map.html', user=user)


@observations_bp.route('/observations')
def observations_feed():
    """Лента всех наблюдений сообщества с возможностью сортировки"""
    user = get_current_user()
    conn = get_db()
    
    # Получаем параметр сортировки из адресной строки
    sort = request.args.get('sort', 'newest')
    
    # Выбираем порядок сортировки (временно убраны popular и views)
    if sort == 'oldest':
        order_by = 'o.observation_date ASC'
    else:
        order_by = 'o.observation_date DESC'
    
    observations = conn.execute(f'''
        SELECT o.*, 
               s.name as species_name, 
               s.category, 
               u.username as user_name, 
               u.id as user_id, 
               u.avatar as user_avatar
        FROM observations o
        JOIN species s ON o.species_id = s.id
        JOIN users u ON o.user_id = u.id
        ORDER BY {order_by}
    ''').fetchall()
    
    conn.close()
    return render_template('observations_feed.html', user=user, observations=observations, current_sort=sort)


@observations_bp.route('/observations/my')
@login_required
def my_observations():
    """Страница со своими наблюдениями (используется в профиле)"""
    user = get_current_user()
    conn = get_db()
    
    observations = conn.execute('''
        SELECT o.*, s.name as species_name
        FROM observations o
        JOIN species s ON o.species_id = s.id
        WHERE o.user_id = ?
        ORDER BY o.observation_date DESC
    ''', (user['id'],)).fetchall()
    
    conn.close()
    return render_template('observations.html', user=user, observations=observations)


# ========== ДОБАВЛЕНИЕ НАБЛЮДЕНИЯ ==========

@observations_bp.route('/observation/add', methods=['GET', 'POST'])
@login_required
def add_observation():
    """Добавление нового наблюдения - форма и обработка"""
    if request.method == 'POST':
        try:
            # Получаем данные из формы
            user_id = request.cookies.get('user_id')
            species_id = request.form['species_id']
            latitude = request.form['latitude']
            longitude = request.form['longitude']
            description = request.form['description']
            weather = request.form.get('weather', '')
            count = request.form.get('count', 1)
            
            # Обработка загруженного фото
            photo_file = request.files.get('photo')
            photo_url = save_photo(photo_file) if photo_file and photo_file.filename else None
            
            conn = get_db()
            conn.execute('''
                INSERT INTO observations 
                (user_id, species_id, latitude, longitude, photo_url, description, weather, count, status, observation_date)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'одобрено', datetime('now', 'localtime'))
            ''', (user_id, species_id, latitude, longitude, photo_url, description, weather, count))
            conn.commit()
            conn.close()
            
            # Начисляем опыт и проверяем достижения
            add_xp(int(user_id), 10, 'добавление наблюдения')
            check_and_award_achievements(int(user_id))
            
            flash('Наблюдение успешно добавлено! +10 XP', 'success')
            return redirect(url_for('observations.observations_feed'))
            
        except Exception as e:
            flash(f'Ошибка: {str(e)}', 'danger')
            return redirect(url_for('observations.add_observation'))
    
    # GET запрос - показываем форму
    conn = get_db()
    species = conn.execute('SELECT * FROM species ORDER BY name').fetchall()
    conn.close()
    return render_template('add_observation.html', user=get_current_user(), species=species)


# ========== РЕДАКТИРОВАНИЕ НАБЛЮДЕНИЯ ==========

@observations_bp.route('/observation/edit/<int:observation_id>', methods=['GET', 'POST'])
@login_required
def edit_observation(observation_id):
    """Редактирование наблюдения - только для автора или администратора"""
    user = get_current_user()
    conn = get_db()
    
    # Получаем текущие данные наблюдения
    observation = conn.execute('''
        SELECT o.*, s.name as species_name, s.id as species_id
        FROM observations o
        JOIN species s ON o.species_id = s.id
        WHERE o.id = ?
    ''', (observation_id,)).fetchone()
    
    if not observation:
        conn.close()
        flash('Наблюдение не найдено', 'danger')
        return redirect(url_for('observations.observations_feed'))
    
    # Проверка прав: автор или администратор
    if observation['user_id'] != user['id'] and user['role'] != 'admin':
        conn.close()
        flash('У вас нет прав для редактирования этого наблюдения', 'danger')
        return redirect(url_for('observations.observations_feed'))
    
    if request.method == 'POST':
        try:
            species_id = request.form['species_id']
            description = request.form['description']
            weather = request.form.get('weather', '')
            count = request.form.get('count', 1)
            latitude = request.form.get('latitude', observation['latitude'])
            longitude = request.form.get('longitude', observation['longitude'])
            
            # Обработка фото - новое или удаление старого
            photo_file = request.files.get('photo')
            new_photo_url = None
            
            if photo_file and photo_file.filename:
                # Загружаем новое фото
                new_photo_url = save_photo(photo_file)
                # Удаляем старое фото, если оно было
                if observation['photo_url'] and new_photo_url:
                    import os
                    from config import Config
                    old_photo_path = os.path.join(Config.UPLOAD_FOLDER, observation['photo_url'])
                    old_thumb_path = os.path.join(Config.UPLOAD_FOLDER, f"thumb_{observation['photo_url']}")
                    if os.path.exists(old_photo_path):
                        os.remove(old_photo_path)
                    if os.path.exists(old_thumb_path):
                        os.remove(old_thumb_path)
                photo_url = new_photo_url
            else:
                # Проверяем, нужно ли удалить текущее фото
                if request.form.get('delete_photo') == 'on' and observation['photo_url']:
                    import os
                    from config import Config
                    old_photo_path = os.path.join(Config.UPLOAD_FOLDER, observation['photo_url'])
                    old_thumb_path = os.path.join(Config.UPLOAD_FOLDER, f"thumb_{observation['photo_url']}")
                    if os.path.exists(old_photo_path):
                        os.remove(old_photo_path)
                    if os.path.exists(old_thumb_path):
                        os.remove(old_thumb_path)
                    photo_url = None
                else:
                    photo_url = observation['photo_url']
            
            # Обновляем запись в базе данных
            conn.execute('''
                UPDATE observations 
                SET species_id = ?, description = ?, weather = ?, count = ?, 
                    latitude = ?, longitude = ?, photo_url = ?
                WHERE id = ?
            ''', (species_id, description, weather, count, latitude, longitude, photo_url, observation_id))
            conn.commit()
            conn.close()
            
            flash('Наблюдение успешно обновлено!', 'success')
            return redirect(url_for('observations.observations_feed'))
            
        except Exception as e:
            conn.close()
            flash(f'Ошибка: {str(e)}', 'danger')
            return redirect(url_for('observations.edit_observation', observation_id=observation_id))
    
    # GET запрос - показываем форму с текущими данными
    species_list = conn.execute('SELECT * FROM species ORDER BY name').fetchall()
    conn.close()
    
    return render_template('edit_observation.html', user=user, observation=observation, species=species_list)


# ========== УДАЛЕНИЕ НАБЛЮДЕНИЯ ==========

@observations_bp.route('/observation/delete/<int:observation_id>', methods=['POST'])
@login_required
def delete_observation(observation_id):
    """Удаление наблюдения - администратор может удалить любое, автор только своё"""
    user = get_current_user()
    conn = get_db()
    
    observation = conn.execute('SELECT * FROM observations WHERE id = ?', (observation_id,)).fetchone()
    
    if not observation:
        conn.close()
        flash('Наблюдение не найдено', 'danger')
        return redirect(url_for('observations.my_observations'))
    
    # Проверка прав
    if user['role'] == 'admin' or user['id'] == observation['user_id']:
        # Удаляем файлы фото, если они есть
        if observation['photo_url']:
            try:
                import os
                from config import Config
                photo_path = os.path.join(Config.UPLOAD_FOLDER, observation['photo_url'])
                thumb_path = os.path.join(Config.UPLOAD_FOLDER, f"thumb_{observation['photo_url']}")
                
                if os.path.exists(photo_path):
                    os.remove(photo_path)
                if os.path.exists(thumb_path):
                    os.remove(thumb_path)
            except:
                pass
        
        conn.execute('DELETE FROM observations WHERE id = ?', (observation_id,))
        conn.commit()
        flash('Наблюдение удалено', 'success')
    else:
        flash('У вас нет прав для удаления', 'danger')
    
    conn.close()
    
    if user['role'] == 'admin':
        return redirect(url_for('admin.admin_panel'))
    else:
        return redirect(url_for('observations.my_observations'))


# ========== API ДЛЯ КАРТЫ И МОДАЛЬНЫХ ОКОН ==========

@observations_bp.route('/api/observations')
def api_observations():
    """API для карты - возвращает все наблюдения в формате GeoJSON"""
    conn = get_db()
    observations = conn.execute('''
        SELECT o.id, o.latitude, o.longitude, o.description, o.count, o.photo_url, o.observation_date,
               s.name as species_name, s.category,
               u.username as user_name, u.id as user_id
        FROM observations o
        JOIN species s ON o.species_id = s.id
        JOIN users u ON o.user_id = u.id
        WHERE o.status = 'одобрено'
        ORDER BY o.observation_date DESC
    ''').fetchall()
    conn.close()
    
    features = []
    for obs in observations:
        features.append({
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [float(obs['longitude']), float(obs['latitude'])]
            },
            "properties": {
                "id": obs['id'],
                "title": f"Наблюдение: {obs['species_name']}",
                "species": obs['species_name'],
                "species_name": obs['species_name'],
                "category": obs['category'],
                "user": obs['user_name'],
                "user_name": obs['user_name'],
                "user_id": obs['user_id'],
                "date": obs['observation_date'],
                "count": obs['count'],
                "description": obs['description'],
                "photo": obs['photo_url'],
                "latitude": float(obs['latitude']),
                "longitude": float(obs['longitude'])
            }
        })
    
    return jsonify({"type": "FeatureCollection", "features": features})


@observations_bp.route('/api/observation/<int:observation_id>')
def api_observation_detail(observation_id):
    """
    API для модального окна - возвращает детальную информацию о наблюдении
    При каждом вызове увеличивает счётчик просмотров
    """
    try:
        conn = get_db()
        
        # Увеличиваем счётчик просмотров
        conn.execute('UPDATE observations SET views = views + 1 WHERE id = ?', (observation_id,))
        conn.commit()
        
        # Получаем все данные о наблюдении, включая аватар автора
        observation = conn.execute('''
            SELECT o.*, 
                   s.name as species_name, 
                   s.category, 
                   s.id as species_id, 
                   u.username as user_name, 
                   u.id as user_id, 
                   u.avatar as user_avatar
            FROM observations o
            JOIN species s ON o.species_id = s.id
            JOIN users u ON o.user_id = u.id
            WHERE o.id = ?
        ''', (observation_id,)).fetchone()
        conn.close()
        
        if not observation:
            return jsonify({'error': 'Наблюдение не найдено'}), 404
        
        # Преобразуем типы данных для JSON
        obs_dict = dict(observation)
        obs_dict['latitude'] = float(obs_dict['latitude'])
        obs_dict['longitude'] = float(obs_dict['longitude'])
        obs_dict['count'] = int(obs_dict['count'])
        
        return jsonify(obs_dict)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@observations_bp.route('/api/species/on-map')
def api_species_on_map():
    """API для карты - возвращает цвета для категорий видов"""
    conn = get_db()
    species = conn.execute('''
        SELECT DISTINCT category, COUNT(*) as count
        FROM species
        GROUP BY category
    ''').fetchall()
    conn.close()
    
    # Цвета для разных категорий видов
    colors = {
        'Животное': '#e53935',
        'Птица': '#3949ab',
        'Растение': '#43a047',
        'Насекомое': '#fb8c00',
        'Гриб': '#8e24aa',
        'Рыба': '#00acc1',
        'Пресмыкающееся': '#7b1fa2'
    }
    
    result = []
    for s in species:
        result.append({
            'category': s['category'],
            'color': colors.get(s['category'], '#666666'),
            'count': s['count']
        })
    
    return jsonify(result)