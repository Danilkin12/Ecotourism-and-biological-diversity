from flask import Blueprint, render_template, request, redirect, url_for, flash, make_response
from werkzeug.security import generate_password_hash, check_password_hash
from ..models.database import get_db
import sqlite3
import secrets
from datetime import datetime, timedelta

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        conn = get_db()
        user = conn.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
        conn.close()
        
        if user and check_password_hash(user['password_hash'], password):
            response = make_response(redirect(url_for('main.index')))
            response.set_cookie('user_id', str(user['id']), max_age=60*60*24*7)
            response.set_cookie('username', user['username'])
            response.set_cookie('role', user['role'])
            flash('✅ Вход выполнен!', 'success')
            return response
        else:
            flash('❌ Неверные данные', 'danger')
    
    return render_template('login.html')

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        full_name = request.form.get('full_name', '')
        role = request.form.get('role', 'tourist')
        
        if len(password) < 6:
            flash('❌ Пароль должен быть не менее 6 символов', 'danger')
            return redirect(url_for('auth.register'))
        
        try:
            password_hash = generate_password_hash(password)
            conn = get_db()
            conn.execute(
                'INSERT INTO users (username, email, password_hash, full_name, role) VALUES (?, ?, ?, ?, ?)',
                (username, email, password_hash, full_name, role)
            )
            conn.commit()
            conn.close()
            flash('✅ Регистрация успешна! Теперь войдите.', 'success')
            return redirect(url_for('auth.login'))
        except sqlite3.IntegrityError:
            flash('❌ Пользователь с таким именем или email уже существует', 'danger')
        except Exception as e:
            flash(f'❌ Ошибка: {str(e)}', 'danger')
    
    return render_template('register.html')

@auth_bp.route('/logout')
def logout():
    response = make_response(redirect(url_for('main.index')))
    response.delete_cookie('user_id')
    response.delete_cookie('username')
    response.delete_cookie('role')
    flash('👋 Вы вышли из системы', 'info')
    return response

# ========== ВОССТАНОВЛЕНИЕ ПАРОЛЯ ==========

@auth_bp.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    """Запрос на восстановление пароля"""
    if request.method == 'POST':
        email = request.form['email']
        conn = get_db()
        user = conn.execute('SELECT id, username FROM users WHERE email = ?', (email,)).fetchone()
        
        if user:
            # Генерируем токен
            token = secrets.token_urlsafe(32)
            expiry = datetime.now() + timedelta(hours=24)
            
            conn.execute('''
                UPDATE users SET reset_token = ?, reset_token_expiry = ? WHERE id = ?
            ''', (token, expiry, user['id']))
            conn.commit()
            
            # В реальном приложении здесь отправляется email
            # Для демо показываем ссылку
            reset_url = url_for('auth.reset_password', token=token, _external=True)
            flash(f'🔗 Ссылка для восстановления: {reset_url}', 'info')
        else:
            flash('📧 Если email зарегистрирован, вы получите ссылку для восстановления', 'info')
        
        conn.close()
        return redirect(url_for('auth.login'))
    
    return render_template('forgot_password.html')

@auth_bp.route('/reset-password/<token>', methods=['GET', 'POST'])
def reset_password(token):
    """Сброс пароля по токену"""
    conn = get_db()
    user = conn.execute('''
        SELECT id FROM users 
        WHERE reset_token = ? AND reset_token_expiry > ?
    ''', (token, datetime.now())).fetchone()
    
    if not user:
        conn.close()
        flash('❌ Ссылка недействительна или истекла', 'danger')
        return redirect(url_for('auth.login'))
    
    if request.method == 'POST':
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        
        if password != confirm_password:
            flash('❌ Пароли не совпадают', 'danger')
            return redirect(url_for('auth.reset_password', token=token))
        
        if len(password) < 6:
            flash('❌ Пароль должен быть не менее 6 символов', 'danger')
            return redirect(url_for('auth.reset_password', token=token))
        
        # Обновляем пароль
        password_hash = generate_password_hash(password)
        conn.execute('''
            UPDATE users SET password_hash = ?, reset_token = NULL, reset_token_expiry = NULL WHERE id = ?
        ''', (password_hash, user['id']))
        conn.commit()
        conn.close()
        
        flash('✅ Пароль успешно изменен! Теперь войдите.', 'success')
        return redirect(url_for('auth.login'))
    
    conn.close()
    return render_template('reset_password.html', token=token)