from flask import Blueprint, render_template, request, jsonify, flash, redirect, url_for
from app.models.database import get_db
from app.utils.decorators import login_required, get_current_user, admin_required
from datetime import datetime

events_bp = Blueprint('events', __name__)

# Типы событий с иконками и цветами
EVENT_TYPES = {
    'Субботник': {'icon': 'fas fa-broom', 'color': '#2e7d32', 'bg': '#e8f5e9'},
    'Экскурсия': {'icon': 'fas fa-binoculars', 'color': '#1565c0', 'bg': '#e3f2fd'},
    'Лекция': {'icon': 'fas fa-chalkboard-user', 'color': '#e65100', 'bg': '#fff3e0'},
    'Выставка': {'icon': 'fas fa-palette', 'color': '#6a1b9a', 'bg': '#f3e5f5'},
    'Другое': {'icon': 'fas fa-leaf', 'color': '#00695c', 'bg': '#e0f2f1'}
}


@events_bp.route('/events')
def events_map():
    """Карта эко-событий"""
    user = get_current_user()
    return render_template('events_map.html', user=user, event_types=EVENT_TYPES)


@events_bp.route('/events/list')
def events_list():
    """Список всех событий"""
    user = get_current_user()
    conn = get_db()
    
    # Фильтры
    event_type = request.args.get('type', '')
    date_from = request.args.get('date_from', '')
    date_to = request.args.get('date_to', '')
    
    query = "SELECT * FROM eco_events WHERE status = 'active'"
    params = []
    
    if event_type:
        query += " AND type = ?"
        params.append(event_type)
    if date_from:
        query += " AND event_date >= ?"
        params.append(date_from)
    if date_to:
        query += " AND event_date <= ?"
        params.append(date_to)
    
    query += " ORDER BY event_date ASC"
    
    events = conn.execute(query, params).fetchall()
    conn.close()
    
    return render_template('events_list.html', user=user, events=events, event_types=EVENT_TYPES)


@events_bp.route('/events/<int:event_id>')
def event_detail(event_id):
    """Детальная страница события"""
    user = get_current_user()
    conn = get_db()
    
    event = conn.execute('SELECT * FROM eco_events WHERE id = ?', (event_id,)).fetchone()
    if not event:
        flash('❌ Событие не найдено', 'danger')
        return redirect(url_for('events.events_map'))
    
    # Проверяем, зарегистрирован ли пользователь
    is_registered = False
    if user:
        reg = conn.execute('''
            SELECT id FROM event_registrations WHERE event_id = ? AND user_id = ?
        ''', (event_id, user['id'])).fetchone()
        is_registered = reg is not None
    
    # Получаем участников
    participants = conn.execute('''
        SELECT u.id, u.username, u.full_name, u.avatar, er.registration_date
        FROM event_registrations er
        JOIN users u ON er.user_id = u.id
        WHERE er.event_id = ?
        ORDER BY er.registration_date ASC
        LIMIT 20
    ''', (event_id,)).fetchall()
    
    conn.close()
    
    return render_template('event_detail.html', user=user, event=event, 
                          is_registered=is_registered, participants=participants,
                          event_types=EVENT_TYPES)


@events_bp.route('/api/events')
def api_events():
    """API для получения событий в формате GeoJSON"""
    conn = get_db()
    events = conn.execute('''
        SELECT * FROM eco_events 
        WHERE status = 'active' AND event_date >= date("now")
        ORDER BY event_date ASC
    ''').fetchall()
    conn.close()
    
    features = []
    for event in events:
        slots_left = event['max_participants'] - event['current_participants'] if event['max_participants'] > 0 else -1
        
        features.append({
            'type': 'Feature',
            'geometry': {
                'type': 'Point',
                'coordinates': [event['longitude'], event['latitude']]
            },
            'properties': {
                'id': event['id'],
                'title': event['title'],
                'description': event['description'][:100] + '...' if len(event['description']) > 100 else event['description'],
                'type': event['type'],
                'icon': EVENT_TYPES.get(event['type'], EVENT_TYPES['Другое'])['icon'],
                'color': EVENT_TYPES.get(event['type'], EVENT_TYPES['Другое'])['color'],
                'event_date': event['event_date'],
                'event_time': event['event_time'],
                'location': event['location'],
                'price': event['price'],
                'max_participants': event['max_participants'],
                'current_participants': event['current_participants'],
                'slots_left': slots_left,
                'slots_text': '∞' if slots_left == -1 else str(slots_left)
            }
        })
    
    return jsonify({'type': 'FeatureCollection', 'features': features})


@events_bp.route('/api/events/register', methods=['POST'])
@login_required
def register_for_event():
    """Запись на событие"""
    user = get_current_user()
    data = request.get_json()
    event_id = data.get('event_id')
    
    conn = get_db()
    
    # Проверяем событие
    event = conn.execute('SELECT * FROM eco_events WHERE id = ?', (event_id,)).fetchone()
    if not event:
        conn.close()
        return jsonify({'success': False, 'error': 'Событие не найдено'})
    
    # Проверяем, есть ли места
    if event['max_participants'] > 0 and event['current_participants'] >= event['max_participants']:
        conn.close()
        return jsonify({'success': False, 'error': 'Нет свободных мест'})
    
    # Проверяем, не зарегистрирован ли уже
    existing = conn.execute('''
        SELECT id FROM event_registrations WHERE event_id = ? AND user_id = ?
    ''', (event_id, user['id'])).fetchone()
    
    if existing:
        # Отписываемся
        conn.execute('DELETE FROM event_registrations WHERE id = ?', (existing['id'],))
        conn.execute('UPDATE eco_events SET current_participants = current_participants - 1 WHERE id = ?', (event_id,))
        conn.commit()
        conn.close()
        return jsonify({'success': True, 'action': 'unregistered', 'message': 'Вы отписались от события'})
    else:
        # Записываемся
        conn.execute('''
            INSERT INTO event_registrations (event_id, user_id, registration_date)
            VALUES (?, ?, datetime("now", "localtime"))
        ''', (event_id, user['id']))
        conn.execute('UPDATE eco_events SET current_participants = current_participants + 1 WHERE id = ?', (event_id,))
        conn.commit()
        conn.close()
        return jsonify({'success': True, 'action': 'registered', 'message': 'Вы успешно записались на событие'})


@events_bp.route('/my-events')
@login_required
def my_events():
    """Мои события (на которые записан пользователь)"""
    user = get_current_user()
    conn = get_db()
    
    upcoming = conn.execute('''
        SELECT e.*, er.registration_date
        FROM event_registrations er
        JOIN eco_events e ON er.event_id = e.id
        WHERE er.user_id = ? AND e.event_date >= date("now")
        ORDER BY e.event_date ASC
    ''', (user['id'],)).fetchall()
    
    past = conn.execute('''
        SELECT e.*, er.registration_date
        FROM event_registrations er
        JOIN eco_events e ON er.event_id = e.id
        WHERE er.user_id = ? AND e.event_date < date("now")
        ORDER BY e.event_date DESC
        LIMIT 10
    ''', (user['id'],)).fetchall()
    
    conn.close()
    
    return render_template('my_events.html', user=user, upcoming=upcoming, past=past, event_types=EVENT_TYPES)