from flask import Blueprint, render_template, jsonify
from ..models.database import get_db
from ..utils.decorators import admin_required, get_current_user, login_required

notifications_bp = Blueprint('notifications', __name__)

def create_notification(type, item_id, item_name, user_id, message):
    """Создать уведомление для админа"""
    conn = get_db()
    conn.execute('''
        INSERT INTO notifications (type, item_id, item_name, user_id, message, status)
        VALUES (?, ?, ?, ?, ?, 'unread')
    ''', (type, item_id, item_name, user_id, message))
    conn.commit()
    conn.close()

def create_user_toast(user_id, title, message, type='toast'):
    """Создать всплывающее уведомление для пользователя"""
    conn = get_db()
    conn.execute('''
        INSERT INTO notifications (type, item_id, item_name, user_id, message, status)
        VALUES (?, ?, ?, ?, ?, 'unread')
    ''', (type, 0, title, user_id, message))
    conn.commit()
    conn.close()

@notifications_bp.route('/api/notifications/count')
@login_required
def get_notifications_count():
    """API для получения количества непрочитанных уведомлений"""
    user = get_current_user()
    
    # Проверяем авторизацию
    if not user:
        return jsonify({'count': 0, 'error': 'Not authenticated'}), 401
    
    # Только админ видит уведомления
    if user['role'] != 'admin':
        return jsonify({'count': 0})
    
    try:
        conn = get_db()
        count = conn.execute('SELECT COUNT(*) as cnt FROM notifications WHERE status = "unread" AND type != "toast"').fetchone()['cnt']
        conn.close()
        return jsonify({'count': count})
    except Exception as e:
        return jsonify({'count': 0})

@notifications_bp.route('/admin/notifications')
@admin_required
def admin_notifications():
    """Страница с уведомлениями для админа"""
    user = get_current_user()
    conn = get_db()
    
    try:
        notifications = conn.execute('''
            SELECT n.*, u.username
            FROM notifications n
            JOIN users u ON n.user_id = u.id
            WHERE n.type != 'toast'
            ORDER BY n.created_at DESC
        ''').fetchall()
        
        # Помечаем как прочитанные
        conn.execute('UPDATE notifications SET status = "read" WHERE type != "toast"')
        conn.commit()
    except Exception as e:
        notifications = []
    
    conn.close()
    return render_template('admin_notifications.html', user=user, notifications=notifications)

@notifications_bp.route('/api/user/toasts')
@login_required
def get_user_toasts():
    """Получение всплывающих уведомлений для пользователя"""
    user = get_current_user()
    if not user:
        return jsonify([])
    
    conn = get_db()
    
    try:
        toasts = conn.execute('''
            SELECT id, message, item_name as title, created_at
            FROM notifications
            WHERE user_id = ? AND type = 'toast' AND status = 'unread'
            ORDER BY created_at DESC
        ''', (user['id'],)).fetchall()
        
        # Отмечаем как прочитанные после получения
        conn.execute('UPDATE notifications SET status = "read" WHERE user_id = ? AND type = "toast"', (user['id'],))
        conn.commit()
        
        result = []
        for t in toasts:
            result.append({
                'id': t['id'],
                'message': t['message'],
                'title': t['title'],
                'created_at': t['created_at']
            })
        
        conn.close()
        return jsonify(result)
    except Exception as e:
        conn.close()
        return jsonify([])