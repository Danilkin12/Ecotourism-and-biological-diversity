import sqlite3
from werkzeug.security import generate_password_hash
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, 'eco_tourism.db')

def get_db():
    conn = sqlite3.connect(DB_PATH, timeout=30, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA journal_mode=WAL')
    conn.execute('PRAGMA synchronous=NORMAL')
    return conn

def init_db():
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT DEFAULT 'tourist',
            full_name TEXT,
            bio TEXT,
            avatar TEXT,
            xp INTEGER DEFAULT 0,
            level INTEGER DEFAULT 1,
            reset_token TEXT,
            reset_token_expiry TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS species (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            latin_name TEXT,
            category TEXT NOT NULL,
            description TEXT,
            conservation_status TEXT,
            user_id INTEGER,
            status TEXT DEFAULT 'на проверке',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS observations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        species_id INTEGER NOT NULL,
        latitude REAL NOT NULL,
        longitude REAL NOT NULL,
        photo_url TEXT,
        description TEXT,
        weather TEXT,
        count INTEGER DEFAULT 1,
        views INTEGER DEFAULT 0,
        favorites_count INTEGER DEFAULT 0,
        observation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        status TEXT DEFAULT 'одобрено',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id),
        FOREIGN KEY (species_id) REFERENCES species (id)
    )
''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS eco_routes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            difficulty TEXT,
            length_km REAL,
            duration_hours INTEGER,
            gear_list TEXT,
            created_by INTEGER,
            status TEXT DEFAULT 'на проверке',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (created_by) REFERENCES users (id)
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS route_points (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            route_id INTEGER NOT NULL,
            latitude REAL NOT NULL,
            longitude REAL NOT NULL,
            order_index INTEGER NOT NULL,
            title TEXT,
            description TEXT,
            species_id INTEGER,
            FOREIGN KEY (route_id) REFERENCES eco_routes (id),
            FOREIGN KEY (species_id) REFERENCES species (id)
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            type TEXT NOT NULL,
            item_id INTEGER NOT NULL,
            item_name TEXT,
            user_id INTEGER NOT NULL,
            message TEXT,
            status TEXT DEFAULT 'unread',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS chat_messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sender_id INTEGER NOT NULL,
            receiver_id INTEGER NOT NULL,
            message TEXT NOT NULL,
            is_read BOOLEAN DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (sender_id) REFERENCES users (id),
            FOREIGN KEY (receiver_id) REFERENCES users (id)
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS favorites (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            item_type TEXT NOT NULL,
            item_id INTEGER NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id),
            UNIQUE(user_id, item_type, item_id)
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS achievements (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT NOT NULL,
            icon TEXT NOT NULL,
            category TEXT NOT NULL,
            requirement_type TEXT NOT NULL,
            requirement_value INTEGER NOT NULL,
            badge_color TEXT DEFAULT 'success'
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS user_achievements (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            achievement_id INTEGER NOT NULL,
            earned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id),
            FOREIGN KEY (achievement_id) REFERENCES achievements (id),
            UNIQUE(user_id, achievement_id)
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS eco_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT,
            type TEXT NOT NULL,
            location TEXT NOT NULL,
            latitude REAL NOT NULL,
            longitude REAL NOT NULL,
            event_date DATE NOT NULL,
            event_time TEXT,
            duration_hours INTEGER DEFAULT 2,
            organizer TEXT,
            organizer_contact TEXT,
            max_participants INTEGER DEFAULT 50,
            current_participants INTEGER DEFAULT 0,
            price TEXT DEFAULT 'Бесплатно',
            image_url TEXT,
            status TEXT DEFAULT 'active',
            created_by INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (created_by) REFERENCES users (id)
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS event_registrations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            status TEXT DEFAULT 'confirmed',
            FOREIGN KEY (event_id) REFERENCES eco_events (id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users (id),
            UNIQUE(event_id, user_id)
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS email_verifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            code TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            expires_at TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    achievements_data = [
        ('Первооткрыватель', 'Добавить первое наблюдение', 'fa-binoculars', 'Наблюдения', 'observations_count', 1, 'info'),
        ('Натуралист', 'Добавить 10 наблюдений', 'fa-leaf', 'Наблюдения', 'observations_count', 10, 'success'),
        ('Следопыт', 'Добавить 50 наблюдений', 'fa-paw', 'Наблюдения', 'observations_count', 50, 'warning'),
        ('Фотограф-любитель', 'Загрузить 5 фото', 'fa-camera', 'Фото', 'photos_count', 5, 'info'),
        ('Фотограф-профи', 'Загрузить 25 фото', 'fa-camera-retro', 'Фото', 'photos_count', 25, 'success'),
        ('Картограф', 'Создать первый маршрут', 'fa-route', 'Маршруты', 'routes_count', 1, 'info'),
        ('Проводник', 'Создать 5 маршрутов', 'fa-compass', 'Маршруты', 'routes_count', 5, 'success'),
        ('Знаток животных', 'Добавить 10 наблюдений животных', 'fa-paw', 'Животные', 'animal_count', 10, 'info'),
        ('Орнитолог', 'Добавить 10 наблюдений птиц', 'fa-dove', 'Птицы', 'bird_count', 10, 'info'),
        ('Ботаник', 'Добавить 10 наблюдений растений', 'fa-leaf', 'Растения', 'plant_count', 10, 'info'),
        ('Энтомолог', 'Добавить 10 наблюдений насекомых', 'fa-bug', 'Насекомые', 'insect_count', 10, 'info'),
    ]
    
    for ach in achievements_data:
        cursor.execute('''
            INSERT OR IGNORE INTO achievements (name, description, icon, category, requirement_type, requirement_value, badge_color)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', ach)
    
    users_data = [
        ('admin', 'admin@ecotour.ru', 'admin123', 'admin', 'Администратор'),
        ('researcher', 'researcher@ecotour.ru', 'pass123', 'researcher', 'Исследователь'),
        ('tourist', 'tourist@ecotour.ru', 'pass123', 'tourist', 'Турист'),
    ]
    
    for username, email, password, role, full_name in users_data:
        cursor.execute("SELECT COUNT(*) FROM users WHERE username = ?", (username,))
        if cursor.fetchone()[0] == 0:
            password_hash = generate_password_hash(password)
            cursor.execute(
                'INSERT INTO users (username, email, password_hash, role, full_name) VALUES (?, ?, ?, ?, ?)',
                (username, email, password_hash, role, full_name)
            )
    
    cursor.execute("SELECT COUNT(*) FROM species WHERE status = 'одобрено'")
    if cursor.fetchone()[0] == 0:
        species_data = [
            ('Бурый медведь', 'Ursus arctos', 'Животное', 'Крупный хищник', 'Уязвимый', 1, 'одобрено'),
            ('Беркут', 'Aquila chrysaetos', 'Птица', 'Хищная птица', 'Находящийся под угрозой', 1, 'одобрено'),
            ('Ландыш майский', 'Convallaria majalis', 'Растение', 'Многолетнее растение', 'Редкий', 1, 'одобрено'),
            ('Махаон', 'Papilio machaon', 'Насекомое', 'Крупная дневная бабочка', 'Сокращающийся', 1, 'одобрено'),
            ('Белка обыкновенная', 'Sciurus vulgaris', 'Животное', 'Грызун', 'Обычный', 1, 'одобрено'),
            ('Сова серая', 'Strix aluco', 'Птица', 'Ночная хищная птица', 'Обычный', 1, 'одобрено'),
        ]
        cursor.executemany(
            'INSERT INTO species (name, latin_name, category, description, conservation_status, user_id, status) VALUES (?, ?, ?, ?, ?, ?, ?)',
            species_data
        )
    
    cursor.execute("SELECT COUNT(*) FROM eco_events")
    if cursor.fetchone()[0] == 0:
        events_data = [
            ('Большой субботник в Лосином острове', 
             'Приглашаем всех желающих на уборку леса от мусора.', 
             'Субботник', 'Лосиный остров, Москва', 55.8558, 37.8173, 
             '2026-06-15', '10:00', 4, 'ЭкоЦентр "Лосиный остров"', '+7 (495) 123-45-67', 50, 0, 'Бесплатно', None, 'active', 1),
            
            ('Экскурсия по Битцевскому лесу с орнитологом', 
             'Увлекательная прогулка с профессиональным орнитологом.', 
             'Экскурсия', 'Битцевский лес, Москва', 55.6000, 37.5500, 
             '2026-06-20', '09:00', 3, 'Общество охраны птиц', '+7 (495) 234-56-78', 20, 0, '500 руб.', None, 'active', 1),
            
            ('Лекция "Красная книга Подмосковья"', 
             'Познавательная лекция о редких видах растений и животных.', 
             'Лекция', 'Центральная библиотека, Москва', 55.7558, 37.6173, 
             '2026-06-25', '18:00', 2, 'Экологический клуб', '+7 (495) 345-67-89', 100, 0, 'Бесплатно', None, 'active', 1),
        ]
        cursor.executemany('''
            INSERT INTO eco_events (title, description, type, location, latitude, longitude, event_date, event_time, duration_hours, organizer, organizer_contact, max_participants, current_participants, price, image_url, status, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', events_data)
    
    conn.commit()
    conn.close()
    print("База данных готова")

if __name__ == '__main__':
    init_db()