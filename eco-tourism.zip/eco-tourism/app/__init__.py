from flask import Flask
from config import Config
from app.routes.chat import chat_bp
from app.routes.notifications import notifications_bp
from app.routes.observations import observations_bp
from app.routes.species import species_bp
from app.routes.eco_routes import eco_routes_bp
from app.routes.favorites import favorites_bp
from app.routes.admin import admin_bp
from app.routes.auth import auth_bp
from app.routes.main import main_bp
from app.achievements import achievements_bp  # ДОБАВЬТЕ ЭТУ СТРОКУ

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    
    # Инициализация папок
    Config.init_app(app)
    
    # Регистрация blueprint'ов
    app.register_blueprint(main_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(observations_bp)
    app.register_blueprint(species_bp)
    app.register_blueprint(eco_routes_bp)
    app.register_blueprint(favorites_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(notifications_bp)
    app.register_blueprint(chat_bp)
    app.register_blueprint(achievements_bp)  # ДОБАВЬТЕ ЭТУ СТРОКУ
    
    return app