import os
from werkzeug.utils import secure_filename
from datetime import datetime
from PIL import Image
from flask import current_app

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def save_photo(file):
    try:
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            unique_filename = f"{timestamp}_{filename}"
            
            upload_folder = current_app.config['UPLOAD_FOLDER']
            os.makedirs(upload_folder, exist_ok=True)
            
            filepath = os.path.join(upload_folder, unique_filename)
            file.save(filepath)
            
            try:
                img = Image.open(filepath)
                img.thumbnail((300, 300))
                thumb_filename = f"thumb_{unique_filename}"
                thumb_path = os.path.join(upload_folder, thumb_filename)
                img.save(thumb_path, optimize=True, quality=85)
            except:
                pass
            
            return unique_filename
        else:
            return None
    except Exception as e:
        return None