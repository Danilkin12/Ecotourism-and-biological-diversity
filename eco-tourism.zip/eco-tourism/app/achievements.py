# achievements.py - система достижений, уровней и опыта
from flask import Blueprint, render_template, jsonify
from app.models.database import get_db
from app.utils.decorators import login_required, get_current_user
from datetime import datetime

achievements_bp = Blueprint('achievements', __name__)


def check_and_award_achievements(user_id):
    """
    Проверка и выдача достижений пользователю.
    Вызывается после: добавления наблюдения, вида, маршрута, фото, получения лайка.
    """
    conn = get_db()
    
    # Собираем статистику пользователя
    stats = conn.execute('''
        SELECT 
            COUNT(DISTINCT o.id) as observations_count,
            COUNT(DISTINCT CASE WHEN s.category IN ('Животное', 'animal') THEN o.id END) as animal_observations,
            COUNT(DISTINCT CASE WHEN s.category IN ('Птица', 'bird') THEN o.id END) as bird_observations,
            COUNT(DISTINCT CASE WHEN s.category IN ('Растение', 'plant') THEN o.id END) as plant_observations,
            COUNT(DISTINCT CASE WHEN s.category IN ('Насекомое', 'insect') THEN o.id END) as insect_observations,
            COUNT(DISTINCT s.id) as species_added,
            COUNT(DISTINCT CASE WHEN s.status = 'одобрено' THEN s.id END) as approved_species,
            COUNT(DISTINCT r.id) as routes_created,
            SUM((SELECT COUNT(*) FROM route_points WHERE route_id = r.id)) as total_route_points,
            COUNT(DISTINCT o.photo_url) as photos_count,
            (SELECT COUNT(*) FROM favorites f WHERE f.item_type = 'observation' AND f.item_id = o.id) as likes_received
        FROM users u
        LEFT JOIN observations o ON u.id = o.user_id
        LEFT JOIN species s ON o.species_id = s.id
        LEFT JOIN eco_routes r ON u.id = r.created_by
        WHERE u.id = ?
    ''', (user_id,)).fetchone()
    
    # Считаем дни активности
    user_created = conn.execute('SELECT created_at FROM users WHERE id = ?', (user_id,)).fetchone()
    days_active = 0
    if user_created and user_created['created_at']:
        try:
            created_date = datetime.strptime(user_created['created_at'], '%Y-%m-%d %H:%M:%S')
            days_active = (datetime.now() - created_date).days
        except:
            days_active = 0
    
    max_route_points = stats['total_route_points'] or 0
    
    # Получаем все достижения из БД
    achievements = conn.execute('SELECT * FROM achievements').fetchall()
    new_achievements = []
    
    for ach in achievements:
        # Проверяем, есть ли уже это достижение у пользователя
        existing = conn.execute('SELECT id FROM user_achievements WHERE user_id = ? AND achievement_id = ?', (user_id, ach['id'])).fetchone()
        if existing:
            continue
        
        # Проверяем условие получения
        earned = False
        if ach['requirement_type'] == 'observations_count':
            earned = (stats['observations_count'] or 0) >= ach['requirement_value']
        elif ach['requirement_type'] == 'animal_count':
            earned = (stats['animal_observations'] or 0) >= ach['requirement_value']
        elif ach['requirement_type'] == 'bird_count':
            earned = (stats['bird_observations'] or 0) >= ach['requirement_value']
        elif ach['requirement_type'] == 'plant_count':
            earned = (stats['plant_observations'] or 0) >= ach['requirement_value']
        elif ach['requirement_type'] == 'insect_count':
            earned = (stats['insect_observations'] or 0) >= ach['requirement_value']
        elif ach['requirement_type'] == 'species_count':
            earned = (stats['species_added'] or 0) >= ach['requirement_value']
        elif ach['requirement_type'] == 'approved_species':
            earned = (stats['approved_species'] or 0) >= ach['requirement_value']
        elif ach['requirement_type'] == 'routes_count':
            earned = (stats['routes_created'] or 0) >= ach['requirement_value']
        elif ach['requirement_type'] == 'route_points':
            earned = max_route_points >= ach['requirement_value']
        elif ach['requirement_type'] == 'photos_count':
            earned = (stats['photos_count'] or 0) >= ach['requirement_value']
        elif ach['requirement_type'] == 'days_active':
            earned = days_active >= ach['requirement_value']
        elif ach['requirement_type'] == 'likes_received':
            earned = (stats['likes_received'] or 0) >= ach['requirement_value']
        
        if earned:
            # Выдаём достижение
            conn.execute('INSERT INTO user_achievements (user_id, achievement_id, earned_at) VALUES (?, ?, datetime("now", "localtime"))', (user_id, ach['id']))
            xp_reward = ach['requirement_value'] * 10
            conn.execute('UPDATE users SET xp = xp + ? WHERE id = ?', (xp_reward, user_id))
            
            new_achievements.append({
                'id': ach['id'],
                'name': ach['name'],
                'description': ach['description'],
                'icon': ach['icon'],
                'badge_color': ach['badge_color'],
                'xp_reward': xp_reward
            })
            
            # Создаём всплывающее уведомление
            conn.execute('INSERT INTO notifications (type, item_id, item_name, user_id, message, status, created_at) VALUES ("toast", ?, ?, ?, ("🏆 НОВОЕ ДОСТИЖЕНИЕ: " || ? || "! +" || ? || " XP"), "unread", datetime("now", "localtime"))', (ach['id'], ach['name'], user_id, ach['name'], xp_reward))
    
    # Обновляем уровень пользователя
    user_xp = conn.execute('SELECT xp FROM users WHERE id = ?', (user_id,)).fetchone()
    old_level = conn.execute('SELECT level FROM users WHERE id = ?', (user_id,)).fetchone()
    old_level_value = old_level['level'] if old_level else 1
    
    if user_xp:
        current_xp = user_xp['xp'] or 0
        new_level = 1 + (current_xp // 100)
        if new_level > old_level_value:
            conn.execute('UPDATE users SET level = ? WHERE id = ?', (new_level, user_id))
            conn.execute('INSERT INTO notifications (type, item_id, item_name, user_id, message, status, created_at) VALUES ("toast", 0, "Повышение уровня", ?, ("🎉 ПОЗДРАВЛЯЕМ! Вы достигли " || CAST(? AS TEXT) || " уровня!"), "unread", datetime("now", "localtime"))', (user_id, new_level))
    
    conn.commit()
    conn.close()
    return new_achievements


def add_xp(user_id, amount, reason=''):
    """
    Добавление опыта пользователю с уведомлением.
    Вызывается после: наблюдение, вид, маршрут, фото, лайк.
    """
    conn = get_db()
    conn.execute('UPDATE users SET xp = xp + ? WHERE id = ?', (amount, user_id))
    conn.execute('INSERT INTO notifications (type, item_id, item_name, user_id, message, status, created_at) VALUES ("toast", 0, "Получен опыт", ?, ("✨ +" || ? || " XP за " || ?), "unread", datetime("now", "localtime"))', (user_id, amount, reason))
    
    # Обновляем уровень
    user_xp = conn.execute('SELECT xp FROM users WHERE id = ?', (user_id,)).fetchone()
    old_level = conn.execute('SELECT level FROM users WHERE id = ?', (user_id,)).fetchone()
    old_level_value = old_level['level'] if old_level else 1
    
    if user_xp:
        current_xp = user_xp['xp'] or 0
        new_level = 1 + (current_xp // 100)
        if new_level > old_level_value:
            conn.execute('UPDATE users SET level = ? WHERE id = ?', (new_level, user_id))
            conn.execute('INSERT INTO notifications (type, item_id, item_name, user_id, message, status, created_at) VALUES ("toast", 0, "Повышение уровня", ?, ("🎉 ПОЗДРАВЛЯЕМ! Вы достигли " || CAST(? AS TEXT) || " уровня!"), "unread", datetime("now", "localtime"))', (user_id, new_level))
    
    conn.commit()
    conn.close()
    check_and_award_achievements(user_id)


@achievements_bp.route('/achievements')
@login_required
def achievements_page():
    """Страница всех достижений пользователя"""
    user = get_current_user()
    conn = get_db()
    
    all_achievements = conn.execute('SELECT a.*, CASE WHEN ua.id IS NOT NULL THEN 1 ELSE 0 END as earned, ua.earned_at FROM achievements a LEFT JOIN user_achievements ua ON a.id = ua.achievement_id AND ua.user_id = ? ORDER BY a.category, earned DESC, a.requirement_value', (user['id'],)).fetchall()
    stats = conn.execute('SELECT COUNT(*) as total, SUM(CASE WHEN ua.id IS NOT NULL THEN 1 ELSE 0 END) as earned FROM achievements a LEFT JOIN user_achievements ua ON a.id = ua.achievement_id AND ua.user_id = ?', (user['id'],)).fetchone()
    recent = conn.execute('SELECT a.*, ua.earned_at FROM user_achievements ua JOIN achievements a ON ua.achievement_id = a.id WHERE ua.user_id = ? ORDER BY ua.earned_at DESC LIMIT 5', (user['id'],)).fetchall()
    user_data = conn.execute('SELECT * FROM users WHERE id = ?', (user['id'],)).fetchone()
    
    conn.close()
    return render_template('achievements.html', user=user_data, achievements=all_achievements, stats=stats, recent=recent)


@achievements_bp.route('/api/achievements/user')
@login_required
def api_user_achievements():
    """API: получение достижений пользователя в JSON"""
    user = get_current_user()
    conn = get_db()
    achievements = conn.execute('SELECT a.*, ua.earned_at FROM achievements a JOIN user_achievements ua ON a.id = ua.achievement_id WHERE ua.user_id = ? ORDER BY ua.earned_at DESC', (user['id'],)).fetchall()
    conn.close()
    return jsonify([dict(ach) for ach in achievements])


@achievements_bp.route('/api/achievements/all')
@login_required
def api_all_achievements():
    """API: получение всех достижений с отметкой о получении"""
    user = get_current_user()
    conn = get_db()
    achievements = conn.execute('SELECT a.*, CASE WHEN ua.id IS NOT NULL THEN 1 ELSE 0 END as earned, ua.earned_at FROM achievements a LEFT JOIN user_achievements ua ON a.id = ua.achievement_id AND ua.user_id = ? ORDER BY a.category, a.requirement_value', (user['id'],)).fetchall()
    conn.close()
    return jsonify([dict(ach) for ach in achievements])


@achievements_bp.route('/api/user/stats')
@login_required
def api_user_stats():
    """API: статистика пользователя для прогресса достижений"""
    user = get_current_user()
    conn = get_db()
    stats = conn.execute('SELECT COUNT(DISTINCT o.id) as observations_count, COUNT(DISTINCT s.id) as species_added, COUNT(DISTINCT r.id) as routes_created, COUNT(DISTINCT o.photo_url) as photos_count, (SELECT COUNT(*) FROM favorites f WHERE f.item_type = "observation" AND f.user_id = ?) as likes_given FROM users u LEFT JOIN observations o ON u.id = o.user_id LEFT JOIN species s ON u.id = s.user_id LEFT JOIN eco_routes r ON u.id = r.created_by WHERE u.id = ?', (user['id'], user['id'])).fetchone()
    likes_received = conn.execute('SELECT COUNT(*) as count FROM favorites f JOIN observations o ON f.item_id = o.id WHERE f.item_type = "observation" AND o.user_id = ?', (user['id'],)).fetchone()
    conn.close()
    return jsonify({
        'observations_count': stats['observations_count'] or 0,
        'species_added': stats['species_added'] or 0,
        'routes_created': stats['routes_created'] or 0,
        'photos_count': stats['photos_count'] or 0,
        'likes_given': stats['likes_given'] or 0,
        'likes_received': likes_received['count'] or 0
    })