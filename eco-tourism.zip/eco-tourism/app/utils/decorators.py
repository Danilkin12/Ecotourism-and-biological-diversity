from functools import wraps
from flask import request, redirect, url_for, flash, jsonify
from ..models.database import get_db

def get_current_user():
    user_id = request.cookies.get('user_id')
    if user_id:
        try:
            conn = get_db()
            user = conn.execute('SELECT * FROM users WHERE id = ?', (user_id,)).fetchone()
            conn.close()
            return dict(user) if user else None
        except:
            return None
    return None

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in request.cookies:
            flash('Требуется авторизация', 'warning')
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        user = get_current_user()
        if not user:
            flash('Требуется авторизация', 'warning')
            return redirect(url_for('auth.login'))
        if user['role'] != 'admin':
            flash('Недостаточно прав', 'danger')
            return redirect(url_for('main.index'))
        return f(*args, **kwargs)
    return decorated_function

def researcher_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        user = get_current_user()
        if not user:
            flash('Требуется авторизация', 'warning')
            return redirect(url_for('auth.login'))
        if user['role'] not in ['admin', 'researcher']:
            flash('Требуются права исследователя', 'danger')
            return redirect(url_for('main.index'))
        return f(*args, **kwargs)
    return decorated_function

def can_edit_item(item_type, item_id):
    """Проверка, может ли пользователь редактировать/удалять элемент"""
    user = get_current_user()
    if not user:
        return False
    
    # Админ допки
    if user['role'] == 'admin':
        return True
    
    conn = get_db()
    if item_type == 'observation':
        item = conn.execute('SELECT user_id FROM observations WHERE id = ?', (item_id,)).fetchone()
    elif item_type == 'species':
        item = conn.execute('SELECT user_id FROM species WHERE id = ?', (item_id,)).fetchone()
    elif item_type == 'route':
        item = conn.execute('SELECT created_by FROM eco_routes WHERE id = ?', (item_id,)).fetchone()
    else:
        item = None
    conn.close()
    
    # Исследователь может редактировать только свои
    if user['role'] == 'researcher' and item and item[0] == user['id']:
        return True
    
    return False