# pip install -r readme.txt
Flask
Pillow
Werkzeug