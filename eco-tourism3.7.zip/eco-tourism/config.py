import os

class Config:
    SECRET_KEY = 'eco-tourism-secret-key-2024'
   
    UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads')
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024
    DATABASE = 'eco_tourism.db'
    
    @staticmethod
    def init_app(app):
        os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)
        print(f"📁 ПАПКА ЗАГРУЗОК ИЗ CONFIG: {Config.UPLOAD_FOLDER}")