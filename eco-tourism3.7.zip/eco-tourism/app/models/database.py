import sqlite3
from werkzeug.security import generate_password_hash

DB_PATH = 'eco_tourism.db'

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    cursor = conn.cursor()
    
    
    # Пользователи
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT DEFAULT 'tourist',
            full_name TEXT,
            bio TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Виды
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS species (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            latin_name TEXT,
            category TEXT NOT NULL,
            description TEXT,
            conservation_status TEXT,
            user_id INTEGER,
            status TEXT DEFAULT 'approved',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    # Наблюдения
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS observations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            species_id INTEGER NOT NULL,
            latitude REAL NOT NULL,
            longitude REAL NOT NULL,
            photo_url TEXT,
            description TEXT,
            weather TEXT,
            count INTEGER DEFAULT 1,
            observation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            status TEXT DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id),
            FOREIGN KEY (species_id) REFERENCES species (id)
        )
    ''')
    
    # Эко-маршруты
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS eco_routes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            difficulty TEXT,
            length_km REAL,
            duration_hours INTEGER,
            created_by INTEGER,
            status TEXT DEFAULT 'approved',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (created_by) REFERENCES users (id)
        )
    ''')
    
    # Точки маршрута
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS route_points (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            route_id INTEGER NOT NULL,
            latitude REAL NOT NULL,
            longitude REAL NOT NULL,
            order_index INTEGER NOT NULL,
            title TEXT,
            description TEXT,
            species_id INTEGER,
            FOREIGN KEY (route_id) REFERENCES eco_routes (id),
            FOREIGN KEY (species_id) REFERENCES species (id)
        )
    ''')
    
    # Уведомления для админа
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            type TEXT NOT NULL,
            item_id INTEGER NOT NULL,
            item_name TEXT,
            user_id INTEGER NOT NULL,
            message TEXT,
            status TEXT DEFAULT 'unread',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    # Тестовые пользователи с разными ролями
    users_data = [
        ('admin', 'admin@ecotour.ru', 'admin123', 'admin', 'Администратор'),
        ('researcher', 'researcher@ecotour.ru', 'pass123', 'researcher', 'Исследователь'),
        ('tourist', 'tourist@ecotour.ru', 'pass123', 'tourist', 'Турист'),
    ]
    
    for username, email, password, role, full_name in users_data:
        cursor.execute("SELECT COUNT(*) FROM users WHERE username = ?", (username,))
        if cursor.fetchone()[0] == 0:
            password_hash = generate_password_hash(password)
            cursor.execute(
                'INSERT INTO users (username, email, password_hash, role, full_name) VALUES (?, ?, ?, ?, ?)',
                (username, email, password_hash, role, full_name)
            )
    
    # Тестовые виды 
    cursor.execute("SELECT COUNT(*) FROM species WHERE status = 'approved'")
    if cursor.fetchone()[0] == 0:
        species_data = [
            ('Бурый медведь', 'Ursus arctos', 'animal', 'Крупный хищник', 'Уязвимый', 1, 'approved'),
            ('Беркут', 'Aquila chrysaetos', 'bird', 'Хищная птица', 'Находящийся под угрозой', 1, 'approved'),
            ('Ландыш майский', 'Convallaria majalis', 'plant', 'Многолетнее растение', 'Редкий', 1, 'approved'),
        ]
        cursor.executemany(
            'INSERT INTO species (name, latin_name, category, description, conservation_status, user_id, status) VALUES (?, ?, ?, ?, ?, ?, ?)',
            species_data
        )
    
    # Тестовый эко-маршрут
    cursor.execute("SELECT COUNT(*) FROM eco_routes")
    if cursor.fetchone()[0] == 0:
        cursor.execute('''
            INSERT INTO eco_routes (name, description, difficulty, length_km, duration_hours, created_by, status)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', ('Экотропа "Лесная сказка"', 'Маршрут по смешанному лесу', 'легкий', 3.5, 2, 1, 'approved'))
        
        route_id = cursor.lastrowid
        
        # Тестовые точки маршрута
        route_points_data = [
            (route_id, 55.7558, 37.6173, 1, 'Начало тропы', 'Старт маршрута', 1),
            (route_id, 55.7565, 37.6185, 2, 'Смотровая площадка', 'Красивый вид на лес', 2),
            (route_id, 55.7570, 37.6200, 3, 'Родник', 'Место отдыха', 3),
        ]
        
        cursor.executemany('''
            INSERT INTO route_points (route_id, latitude, longitude, order_index, title, description, species_id)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', route_points_data)
    
    conn.commit()
    conn.close()
    print("✅ База данных полностью готова!")