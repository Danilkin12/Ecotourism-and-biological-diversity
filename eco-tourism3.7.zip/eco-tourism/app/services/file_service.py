import os
from werkzeug.utils import secure_filename
from datetime import datetime
from PIL import Image
from flask import current_app

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def save_photo(file):
    """Сохраняет фото и создает миниатюру"""
    try:
        if file and allowed_file(file.filename):
            # Создаем уникальное имя файла
            filename = secure_filename(file.filename)
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            unique_filename = f"{timestamp}_{filename}"
            
            # Получаем папку загрузок из конфига
            upload_folder = current_app.config['UPLOAD_FOLDER']
            
            # Создаем папку, если её нет
            os.makedirs(upload_folder, exist_ok=True)
            
            # Полный путь для сохранения
            filepath = os.path.join(upload_folder, unique_filename)
            
            print(f"💾 Сохраняем файл: {filepath}")
            
            # Сохраняем оригинал
            file.save(filepath)
            print(f"✅ Оригинал сохранен, размер: {os.path.getsize(filepath)} байт")
            
            # Создаем миниатюру
            try:
                img = Image.open(filepath)
                img.thumbnail((300, 300))
                thumb_filename = f"thumb_{unique_filename}"
                thumb_path = os.path.join(upload_folder, thumb_filename)
                img.save(thumb_path, optimize=True, quality=85)
                print(f"✅ Миниатюра создана: {thumb_path}, размер: {os.path.getsize(thumb_path)} байт")
            except Exception as e:
                print(f"❌ Ошибка при создании миниатюры: {e}")
            
            return unique_filename
        else:
            print("❌ Неподдерживаемый формат файла")
            return None
    except Exception as e:
        print(f"❌ Ошибка сохранения фото: {e}")
        return None