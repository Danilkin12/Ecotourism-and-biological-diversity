from flask import Blueprint, render_template, jsonify
from ..models.database import get_db
from ..utils.decorators import admin_required, get_current_user

notifications_bp = Blueprint('notifications', __name__)

def create_notification(type, item_id, item_name, user_id, message):
    """Создать уведомление для админа"""
    conn = get_db()
    conn.execute('''
        INSERT INTO notifications (type, item_id, item_name, user_id, message)
        VALUES (?, ?, ?, ?, ?)
    ''', (type, item_id, item_name, user_id, message))
    conn.commit()
    conn.close()

@notifications_bp.route('/api/notifications/count')
def get_notifications_count():
    """API для получения количества непрочитанных уведомлений"""
    user = get_current_user()
    
    # Проверяем авторизацию
    if not user:
        return jsonify({'count': 0, 'error': 'Not authenticated'}), 401
    
    # Только админ видит уведомления
    if user['role'] != 'admin':
        return jsonify({'count': 0})
    
    try:
        conn = get_db()
        count = conn.execute('SELECT COUNT(*) as cnt FROM notifications WHERE status = "unread"').fetchone()['cnt']
        conn.close()
        return jsonify({'count': count})
    except Exception as e:
        print(f"❌ Ошибка получения уведомлений: {e}")
        return jsonify({'count': 0})

@notifications_bp.route('/admin/notifications')
@admin_required
def admin_notifications():
    """Страница с уведомлениями для админа"""
    user = get_current_user()
    conn = get_db()
    
    try:
        notifications = conn.execute('''
            SELECT n.*, u.username
            FROM notifications n
            JOIN users u ON n.user_id = u.id
            ORDER BY n.created_at DESC
        ''').fetchall()
        
        # Помечаем как прочитанные
        conn.execute('UPDATE notifications SET status = "read"')
        conn.commit()
    except Exception as e:
        print(f"❌ Ошибка загрузки уведомлений: {e}")
        notifications = []
    
    conn.close()
    return render_template('admin_notifications.html', user=user, notifications=notifications)