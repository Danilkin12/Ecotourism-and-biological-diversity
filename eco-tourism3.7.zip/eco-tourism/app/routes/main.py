from flask import Blueprint, render_template, send_from_directory, current_app, abort, request, flash, redirect, url_for, make_response
from ..models.database import get_db
from ..utils.decorators import get_current_user, login_required
import os

main_bp = Blueprint('main', __name__)

@main_bp.route('/')
def index():
    user = get_current_user()
    conn = get_db()
    
    observations = conn.execute('''
        SELECT o.*, s.name as species_name, u.username as user_name
        FROM observations o
        JOIN species s ON o.species_id = s.id
        JOIN users u ON o.user_id = u.id
        ORDER BY o.observation_date DESC
        LIMIT 6
    ''').fetchall()
    
    species = conn.execute('SELECT * FROM species WHERE status = "approved" ORDER BY name LIMIT 6').fetchall()
    
    conn.close()
    return render_template('index.html', user=user, observations=observations, species=species)

@main_bp.route('/profile')
@login_required
def profile():
    user = get_current_user()
    conn = get_db()
    
    stats = conn.execute('''
        SELECT 
            COUNT(*) as total_observations,
            COUNT(DISTINCT species_id) as unique_species,
            SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved_count,
            SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_count
        FROM observations 
        WHERE user_id = ?
    ''', (user['id'],)).fetchone()
    
    recent_observations = conn.execute('''
        SELECT o.*, s.name as species_name, s.category
        FROM observations o
        JOIN species s ON o.species_id = s.id
        WHERE o.user_id = ?
        ORDER BY o.observation_date DESC
        LIMIT 5
    ''', (user['id'],)).fetchall()
    
    user_routes = conn.execute('''
        SELECT * FROM eco_routes 
        WHERE created_by = ?
        ORDER BY created_at DESC
        LIMIT 5
    ''', (user['id'],)).fetchall()
    
    conn.close()
    
    return render_template('profile.html', user=user, stats=stats, 
                         recent_observations=recent_observations, 
                         user_routes=user_routes)

@main_bp.route('/profile/update', methods=['POST'])
@login_required
def update_profile():
    """Обновление профиля пользователя"""
    user = get_current_user()
    conn = get_db()
    
    full_name = request.form.get('full_name', '')
    bio = request.form.get('bio', '')
    
    try:
        conn.execute('''
            UPDATE users 
            SET full_name = ?, bio = ? 
            WHERE id = ?
        ''', (full_name, bio, user['id']))
        conn.commit()
        flash('✅ Профиль успешно обновлен!', 'success')
    except Exception as e:
        flash(f'❌ Ошибка: {str(e)}', 'danger')
    finally:
        conn.close()
    
    return redirect(url_for('main.profile'))

@main_bp.route('/uploads/<filename>')
def uploaded_file(filename):
    """Просмотр загруженных файлов"""
    try:
        upload_folder = current_app.config['UPLOAD_FOLDER']
        file_path = os.path.join(upload_folder, filename)
        
        print(f"🔍 Запрос файла: {filename}")
        print(f"📁 Папка uploads: {upload_folder}")
        print(f"📁 Полный путь: {file_path}")
        
        if os.path.exists(file_path):
            print(f"✅ Файл найден! Размер: {os.path.getsize(file_path)} байт")
            return send_from_directory(upload_folder, filename)
        else:
            print(f"❌ Файл НЕ найден!")
            
            if os.path.exists(upload_folder):
                files = os.listdir(upload_folder)
                print(f"📁 Файлы в папке ({len(files)}):")
                for f in files:
                    print(f"   - {f}")
            
            return "Файл не найден", 404
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        return str(e), 500

@main_bp.route('/uploads/thumb_<filename>')
def uploaded_thumb(filename):
    """Просмотр миниатюр"""
    return uploaded_file(f"thumb_{filename}")

# ========== НОВЫЕ СТРАНИЦЫ ==========

@main_bp.route('/about')
def about():
    """Страница 'О нас'"""
    user = get_current_user()
    return render_template('about.html', user=user)

@main_bp.route('/contacts')
def contacts():
    """Страница 'Контакты'"""
    user = get_current_user()
    return render_template('contacts.html', user=user)

@main_bp.route('/help')
def help():
    """Страница 'Помощь'"""
    user = get_current_user()
    return render_template('help.html', user=user)

@main_bp.route('/docs')
def docs():
    """Страница 'Документация' для разработчиков"""
    user = get_current_user()
    return render_template('docs.html', user=user)

@main_bp.route('/api/docs')
def api_docs():
    """Страница 'API' документация"""
    user = get_current_user()
    return render_template('api_docs.html', user=user)

@main_bp.route('/profile/delete', methods=['POST'])
@login_required
def delete_account():
    """Удаление аккаунта пользователя"""
    user = get_current_user()
    
    # Админ не может удалить свой аккаунт через эту функцию
    if user['role'] == 'admin':
        flash('❌ Администратор не может удалить свой аккаунт через профиль', 'danger')
        return redirect(url_for('main.profile'))
    
    conn = get_db()
    
    try:
        # Удаляем все наблюдения пользователя
        conn.execute('DELETE FROM observations WHERE user_id = ?', (user['id'],))
        
        # Удаляем все маршруты пользователя
        routes = conn.execute('SELECT id FROM eco_routes WHERE created_by = ?', (user['id'],)).fetchall()
        for route in routes:
            conn.execute('DELETE FROM route_points WHERE route_id = ?', (route['id'],))
        conn.execute('DELETE FROM eco_routes WHERE created_by = ?', (user['id'],))
        
        # Удаляем все виды пользователя
        conn.execute('DELETE FROM species WHERE user_id = ?', (user['id'],))
        
        # Удаляем пользователя
        conn.execute('DELETE FROM users WHERE id = ?', (user['id'],))
        conn.commit()
        
        # Выходим из аккаунта
        response = make_response(redirect(url_for('main.index')))
        response.delete_cookie('user_id')
        response.delete_cookie('username')
        response.delete_cookie('role')
        
        flash('✅ Ваш аккаунт и все данные успешно удалены', 'success')
        return response
        
    except Exception as e:
        conn.rollback()
        flash(f'❌ Ошибка при удалении аккаунта: {str(e)}', 'danger')
        return redirect(url_for('main.profile'))
    finally:
        conn.close()