from flask import Blueprint, render_template
from ..models.database import get_db
from ..utils.decorators import admin_required, get_current_user

admin_bp = Blueprint('admin', __name__)

@admin_bp.route('/admin')
@admin_required
def admin_panel():
    user = get_current_user()
    conn = get_db()
    
    # Статистика
    stats = {
        'users': conn.execute('SELECT COUNT(*) as count FROM users').fetchone()['count'],
        'observations': conn.execute('SELECT COUNT(*) as count FROM observations').fetchone()['count'],
        'species': conn.execute('SELECT COUNT(*) as count FROM species').fetchone()['count'],
        'routes': conn.execute('SELECT COUNT(*) as count FROM eco_routes').fetchone()['count'],
        'pending_species': conn.execute('SELECT COUNT(*) as count FROM species WHERE status = "pending"').fetchone()['count'],
        'pending_routes': conn.execute('SELECT COUNT(*) as count FROM eco_routes WHERE status = "pending"').fetchone()['count']
    }
    
    # Все пользователи 
    all_users = conn.execute('''
        SELECT 
            u.id,
            u.username,
            u.email,
            u.full_name,
            u.role,
            u.bio,
            u.created_at,
            (SELECT COUNT(*) FROM observations WHERE user_id = u.id) as observations_count,
            (SELECT COUNT(*) FROM species WHERE user_id = u.id) as species_count,
            (SELECT COUNT(*) FROM eco_routes WHERE created_by = u.id) as routes_count
        FROM users u
        ORDER BY u.created_at DESC
    ''').fetchall()
    
    # Все наблюдения
    observations = conn.execute('''
        SELECT o.*, s.name as species_name, u.username as user_name
        FROM observations o
        JOIN species s ON o.species_id = s.id
        JOIN users u ON o.user_id = u.id
        ORDER BY o.created_at DESC
        LIMIT 50
    ''').fetchall()
    
    # Все виды
    all_species = conn.execute('''
        SELECT s.*, u.username as creator_name
        FROM species s
        LEFT JOIN users u ON s.user_id = u.id
        ORDER BY s.created_at DESC
    ''').fetchall()
    
    # Все маршруты
    all_routes = conn.execute('''
        SELECT r.*, u.username as creator_name
        FROM eco_routes r
        LEFT JOIN users u ON r.created_by = u.id
        ORDER BY r.created_at DESC
    ''').fetchall()
    
    conn.close()
    
    return render_template('admin.html', user=user, stats=stats, 
                         observations=observations, all_species=all_species, 
                         all_routes=all_routes, all_users=all_users)

@admin_bp.route('/api/user/<int:user_id>')
@admin_required
def api_user_details(user_id):
    """API для получения детальной информации о пользователе"""
    conn = get_db()
    
    user = conn.execute('''
        SELECT 
            u.id,
            u.username,
            u.email,
            u.full_name,
            u.role,
            u.bio,
            u.created_at,
            (SELECT COUNT(*) FROM observations WHERE user_id = u.id) as observations_count,
            (SELECT COUNT(*) FROM species WHERE user_id = u.id) as species_count,
            (SELECT COUNT(*) FROM eco_routes WHERE created_by = u.id) as routes_count
        FROM users u
        WHERE u.id = ?
    ''', (user_id,)).fetchone()
    
    conn.close()
    
    if not user:
        return jsonify({'error': 'Пользователь не найден'}), 404
    
    return jsonify(dict(user))

@admin_bp.route('/admin/user/delete/<int:user_id>', methods=['POST'])
@admin_required
def delete_user(user_id):
    current_admin = get_current_user()
    
    # Нельзя удалить самого себя 
    if current_admin['id'] == user_id:
        flash('❌ Нельзя удалить свой собственный аккаунт', 'danger')
        return redirect(url_for('admin.admin_panel'))
    
    conn = get_db()
    
    # Получаем информацию о пользователе
    user = conn.execute('SELECT username, role FROM users WHERE id = ?', (user_id,)).fetchone()
    
    if not user:
        conn.close()
        flash('❌ Пользователь не найден', 'danger')
        return redirect(url_for('admin.admin_panel'))
    
    # Нельзя удалять других админов
    if user['role'] == 'admin':
        conn.close()
        flash('❌ Нельзя удалить другого администратора', 'danger')
        return redirect(url_for('admin.admin_panel'))
    
    try:
        # Удаляем все наблюдения пользователя
        conn.execute('DELETE FROM observations WHERE user_id = ?', (user_id,))
        # Удаляем все маршруты пользователя
        conn.execute('DELETE FROM eco_routes WHERE created_by = ?', (user_id,))
        # Удаляем все виды пользователя
        conn.execute('DELETE FROM species WHERE user_id = ?', (user_id,))
        # Удаляем пользователя
        conn.execute('DELETE FROM users WHERE id = ?', (user_id,))
        conn.commit()
        flash(f'✅ Пользователь {user["username"]} и все его данные удалены', 'success')
    except Exception as e:
        flash(f'❌ Ошибка при удалении: {e}', 'danger')
    finally:
        conn.close()
    
    return redirect(url_for('admin.admin_panel'))