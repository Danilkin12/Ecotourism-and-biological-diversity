from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from ..models.database import get_db
from ..services.file_service import save_photo
from ..utils.decorators import login_required, get_current_user

observations_bp = Blueprint('observations', __name__)

@observations_bp.route('/observations/map')
def observations_map():
    return render_template('map.html', user=get_current_user())

@observations_bp.route('/api/observations')
def api_observations():
    conn = get_db()
    observations = conn.execute('''
        SELECT o.*, s.name as species_name, s.category, u.username as user_name
        FROM observations o
        JOIN species s ON o.species_id = s.id
        JOIN users u ON o.user_id = u.id
        ORDER BY o.observation_date DESC
    ''').fetchall()
    conn.close()
    
    features = []
    for obs in observations:
        features.append({
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [float(obs['longitude']), float(obs['latitude'])]
            },
            "properties": {
                "id": obs['id'],
                "title": f"Наблюдение: {obs['species_name']}",
                "species": obs['species_name'],
                "species_id": obs['species_id'],
                "category": obs['category'],
                "user": obs['user_name'],
                "user_id": obs['user_id'],
                "date": obs['observation_date'],
                "count": obs['count'],
                "description": obs['description'],
                "photo": obs['photo_url'],
                "weather": obs['weather']
            }
        })
    
    return jsonify({"type": "FeatureCollection", "features": features})

@observations_bp.route('/api/observation/<int:observation_id>')
def api_observation_detail(observation_id):
    """API для получения деталей конкретного наблюдения"""
    try:
        conn = get_db()
        observation = conn.execute('''
            SELECT o.*, s.name as species_name, s.category, u.username as user_name
            FROM observations o
            JOIN species s ON o.species_id = s.id
            JOIN users u ON o.user_id = u.id
            WHERE o.id = ?
        ''', (observation_id,)).fetchone()
        conn.close()
        
        if not observation:
            return jsonify({'error': 'Наблюдение не найдено'}), 404
        
        obs_dict = dict(observation)
        obs_dict['latitude'] = float(obs_dict['latitude'])
        obs_dict['longitude'] = float(obs_dict['longitude'])
        obs_dict['count'] = int(obs_dict['count'])
        
        return jsonify(obs_dict)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@observations_bp.route('/observations')
def observations_feed():
    """Лента всех наблюдений"""
    user = get_current_user()
    conn = get_db()
    
    observations = conn.execute('''
        SELECT o.*, s.name as species_name, s.category, u.username as user_name,
               u.full_name
        FROM observations o
        JOIN species s ON o.species_id = s.id
        JOIN users u ON o.user_id = u.id
        ORDER BY o.observation_date DESC
    ''').fetchall()
    
    conn.close()
    return render_template('observations_feed.html', user=user, observations=observations)

@observations_bp.route('/observation/add', methods=['GET', 'POST'])
@login_required
def add_observation():
    if request.method == 'POST':
        try:
            user_id = request.cookies.get('user_id')
            species_id = request.form['species_id']
            latitude = request.form['latitude']
            longitude = request.form['longitude']
            description = request.form['description']
            weather = request.form.get('weather', '')
            count = request.form.get('count', 1)
            
            photo_file = request.files.get('photo')
            photo_url = None
            if photo_file and photo_file.filename:
                photo_url = save_photo(photo_file)
            
            conn = get_db()
            cursor = conn.cursor()
            
            from datetime import datetime
            observation_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            
            cursor.execute('''
                INSERT INTO observations 
                (user_id, species_id, latitude, longitude, photo_url, description, weather, count, status, observation_date)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (user_id, species_id, latitude, longitude, photo_url, description, weather, count, 'approved', observation_date))
            
            conn.commit()
            conn.close()
            
            flash('✅ Наблюдение успешно добавлено!', 'success')
            return redirect(url_for('observations.observations_feed'))
            
        except Exception as e:
            flash(f'❌ Ошибка: {str(e)}', 'danger')
            return redirect(url_for('observations.add_observation'))
    
    conn = get_db()
    species = conn.execute('SELECT * FROM species ORDER BY name').fetchall()
    conn.close()
    return render_template('add_observation.html', user=get_current_user(), species=species)

@observations_bp.route('/observations/my')
@login_required
def my_observations():
    user_id = request.cookies.get('user_id')
    conn = get_db()
    observations = conn.execute('''
        SELECT o.*, s.name as species_name
        FROM observations o
        JOIN species s ON o.species_id = s.id
        WHERE o.user_id = ?
        ORDER BY o.observation_date DESC
    ''', (user_id,)).fetchall()
    conn.close()
    return render_template('observations.html', user=get_current_user(), observations=observations)

@observations_bp.route('/observation/delete/<int:observation_id>', methods=['POST'])
@login_required
def delete_observation(observation_id):
    """Удаление наблюдения (админ может всё, исследователь - только своё)"""
    user = get_current_user()
    conn = get_db()
    
    # Получаем информацию о наблюдении
    observation = conn.execute('SELECT * FROM observations WHERE id = ?', (observation_id,)).fetchone()
    
    if not observation:
        conn.close()
        flash('❌ Наблюдение не найдено', 'danger')
        return redirect(url_for('observations.my_observations'))
    
    # АДМИН МОЖЕТ УДАЛЯТЬ ВСЁ мухухухухухееееее
    if user['role'] == 'admin':
        # Удаляем фото, если есть
        if observation['photo_url']:
            try:
                import os
                from config import Config
                photo_path = os.path.join(Config.UPLOAD_FOLDER, observation['photo_url'])
                thumb_path = os.path.join(Config.UPLOAD_FOLDER, f"thumb_{observation['photo_url']}")
                
                if os.path.exists(photo_path):
                    os.remove(photo_path)
                if os.path.exists(thumb_path):
                    os.remove(thumb_path)
            except:
                pass
        
        conn.execute('DELETE FROM observations WHERE id = ?', (observation_id,))
        conn.commit()
        conn.close()
        flash('✅ Наблюдение удалено администратором', 'success')
        return redirect(url_for('admin.admin_panel'))
    
    # ИССЛЕДОВАТЕЛЬ МОЖЕТ УДАЛЯТЬ ТОЛЬКО СВОЁ
    elif user['role'] == 'researcher' and user['id'] == observation['user_id']:
        if observation['photo_url']:
            try:
                import os
                from config import Config
                photo_path = os.path.join(Config.UPLOAD_FOLDER, observation['photo_url'])
                thumb_path = os.path.join(Config.UPLOAD_FOLDER, f"thumb_{observation['photo_url']}")
                
                if os.path.exists(photo_path):
                    os.remove(photo_path)
                if os.path.exists(thumb_path):
                    os.remove(thumb_path)
            except:
                pass
        
        conn.execute('DELETE FROM observations WHERE id = ?', (observation_id,))
        conn.commit()
        conn.close()
        flash('✅ Ваше наблюдение удалено', 'success')
        return redirect(url_for('observations.my_observations'))
    
    # ТУРИСТ НЕ МОЖЕТ УДАЛЯТЬ 
    else:
        conn.close()
        flash('❌ У вас нет прав для удаления этого наблюдения', 'danger')
        return redirect(url_for('observations.observations_feed'))