from flask import Blueprint, render_template, request, redirect, url_for, flash, make_response
from werkzeug.security import generate_password_hash, check_password_hash
from ..models.database import get_db
import sqlite3  # 👈 ВАЖНО: добавить этот импорт!

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        conn = get_db()
        user = conn.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
        conn.close()
        
        if user and check_password_hash(user['password_hash'], password):
            response = make_response(redirect(url_for('main.index')))
            response.set_cookie('user_id', str(user['id']), max_age=60*60*24*7)
            response.set_cookie('username', user['username'])
            response.set_cookie('role', user['role'])
            flash('Вход выполнен!', 'success')
            return response
        else:
            flash('Неверные данные', 'danger')
    
    return render_template('login.html')

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        full_name = request.form.get('full_name', '')
        role = request.form.get('role', 'tourist')  # Получаем роль из формы
        
        # Проверка пароля
        if len(password) < 6:
            flash('❌ Пароль должен быть не менее 6 символов', 'danger')
            return redirect(url_for('auth.register'))
        
        try:
            password_hash = generate_password_hash(password)
            conn = get_db()
            conn.execute(
                'INSERT INTO users (username, email, password_hash, full_name, role) VALUES (?, ?, ?, ?, ?)',
                (username, email, password_hash, full_name, role)
            )
            conn.commit()
            conn.close()
            flash('✅ Регистрация успешна! Теперь войдите.', 'success')
            return redirect(url_for('auth.login'))
        except sqlite3.IntegrityError:  # 👈 теперь работает!
            flash('❌ Пользователь с таким именем или email уже существует', 'danger')
        except Exception as e:
            flash(f'❌ Ошибка: {str(e)}', 'danger')
    
    return render_template('register.html')

@auth_bp.route('/logout')
def logout():
    response = make_response(redirect(url_for('main.index')))
    response.delete_cookie('user_id')
    response.delete_cookie('username')
    response.delete_cookie('role')
    flash('Вы вышли из системы', 'info')
    return response