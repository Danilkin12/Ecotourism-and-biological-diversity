from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from ..models.database import get_db
from ..utils.decorators import login_required, get_current_user, admin_required, researcher_required, can_edit_item
from .notifications import create_notification

eco_routes_bp = Blueprint('eco_routes', __name__)

# ОСНОВНЫЕ МАРШРУТЫ 

@eco_routes_bp.route('/eco-routes')
def eco_routes_list():
    """Список всех одобренных маршрутов"""
    user = get_current_user()
    conn = get_db()
    
    # только одобренные маршруты для всех пользователей
    routes = conn.execute('''
        SELECT e.*, u.username as creator_name,
               (SELECT COUNT(*) FROM route_points WHERE route_id = e.id) as points_count
        FROM eco_routes e
        JOIN users u ON e.created_by = u.id
        WHERE e.status = 'approved'
        ORDER BY e.created_at DESC
    ''').fetchall()
    
    conn.close()
    return render_template('eco_routes.html', user=user, routes=routes)

@eco_routes_bp.route('/eco-route/<int:route_id>')
def eco_route_detail(route_id):
    """Детальная страница маршрута"""
    user = get_current_user()
    conn = get_db()
    
    route = conn.execute('''
        SELECT e.*, u.username as creator_name, u.full_name
        FROM eco_routes e
        JOIN users u ON e.created_by = u.id
        WHERE e.id = ?
    ''', (route_id,)).fetchone()
    
    if not route:
        conn.close()
        flash('Маршрут не найден', 'danger')
        return redirect(url_for('eco_routes.eco_routes_list'))
    
    # Проверяем статус, показываем только одобренные 
    if route['status'] != 'approved' and not (user and (user['role'] == 'admin' or user['id'] == route['created_by'])):
        conn.close()
        flash('Маршрут еще не одобрен', 'warning')
        return redirect(url_for('eco_routes.eco_routes_list'))
    
    route_points = conn.execute('''
        SELECT rp.*, s.name as species_name, s.category
        FROM route_points rp
        LEFT JOIN species s ON rp.species_id = s.id
        WHERE rp.route_id = ?
        ORDER BY rp.order_index
    ''', (route_id,)).fetchall()
    
    conn.close()
    return render_template('eco_route_detail.html', user=user, route=route, route_points=route_points)

# СОЗДАНИЕ МАРШРУТА 

@eco_routes_bp.route('/eco-route/create', methods=['GET', 'POST'])
@login_required
def create_eco_route():
    """Создание нового маршрута (исследователи - на модерацию, админ - сразу)"""
    user = get_current_user()
    
    if request.method == 'POST':
        name = request.form['name']
        description = request.form['description']
        difficulty = request.form['difficulty']
        length_km = request.form.get('length_km', 0)
        duration_hours = request.form.get('duration_hours', 0)
        
        if not name or not description or not difficulty:
            flash('❌ Заполните все обязательные поля', 'danger')
            return redirect(url_for('eco_routes.create_eco_route'))
        
        conn = get_db()
        cursor = conn.cursor()
        
        # Админ создаёт сразу одобренный маршрут, исследователь на модерацию
        status = 'approved' if user['role'] == 'admin' else 'pending'
        
        cursor.execute('''
            INSERT INTO eco_routes (name, description, difficulty, length_km, duration_hours, created_by, status)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (name, description, difficulty, length_km, duration_hours, user['id'], status))
        
        route_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        # Если админ, то сразу на добавление точек
        if user['role'] == 'admin':
            flash(f'✅ Маршрут "{name}" создан! Теперь добавьте точки.', 'success')
            return redirect(url_for('eco_routes.add_route_points', route_id=route_id))
        else:
            # Исследователь уведомление админу
            create_notification(
                type='route',
                item_id=route_id,
                item_name=name,
                user_id=user['id'],
                message=f'Исследователь {user["username"]} предложил новый маршрут: {name}'
            )
            flash(f'✅ Маршрут "{name}" отправлен на модерацию!', 'success')
            return redirect(url_for('eco_routes.eco_routes_list'))
    
    return render_template('create_eco_route.html', user=user)

# ДОБАВЛЕНИЕ ТОЧЕК МАРШРУТА 

@eco_routes_bp.route('/eco-route/<int:route_id>/add-points', methods=['GET', 'POST'])
@login_required
def add_route_points(route_id):
    """Добавление точек к маршруту"""
    user = get_current_user()
    conn = get_db()
    
    # Проверяем, что пользователь является создателем маршрута или админом
    route = conn.execute('SELECT * FROM eco_routes WHERE id = ?', (route_id,)).fetchone()
    
    if not route:
        conn.close()
        flash('Маршрут не найден', 'danger')
        return redirect(url_for('eco_routes.eco_routes_list'))
    
    if route['created_by'] != user['id'] and user['role'] != 'admin':
        conn.close()
        flash('У вас нет прав для редактирования этого маршрута', 'danger')
        return redirect(url_for('eco_routes.eco_route_detail', route_id=route_id))
    
    if request.method == 'POST':
        titles = request.form.getlist('title[]')
        lats = request.form.getlist('lat[]')
        lngs = request.form.getlist('lng[]')
        descriptions = request.form.getlist('description[]')
        species_ids = request.form.getlist('species_id[]')
        
        # Удаляем старые точки
        conn.execute('DELETE FROM route_points WHERE route_id = ?', (route_id,))
        
        # Добавляем новые точки
        for i in range(len(titles)):
            if titles[i] and lats[i] and lngs[i]:
                species_id = species_ids[i] if i < len(species_ids) and species_ids[i] else None
                conn.execute('''
                    INSERT INTO route_points (route_id, latitude, longitude, order_index, title, description, species_id)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', (route_id, float(lats[i]), float(lngs[i]), i+1, titles[i], descriptions[i], species_id))
        
        conn.commit()
        conn.close()
        flash('✅ Точки маршрута добавлены!', 'success')
        return redirect(url_for('eco_routes.eco_route_detail', route_id=route_id))
    
    # показываем форму
    species = conn.execute('SELECT * FROM species WHERE status = "approved" ORDER BY name').fetchall()
    existing_points = conn.execute('SELECT * FROM route_points WHERE route_id = ? ORDER BY order_index', (route_id,)).fetchall()
    conn.close()
    
    return render_template('add_route_points.html', user=user, route=route, species=species, existing_points=existing_points)

# МОДЕРАЦИЯ МАРШРУТОВ

@eco_routes_bp.route('/eco-routes/pending')
@admin_required
def pending_routes():
    """Список маршрутов на модерации (только для админа)"""
    user = get_current_user()
    conn = get_db()
    
    routes = conn.execute('''
        SELECT e.*, u.username as creator_name, u.full_name
        FROM eco_routes e
        JOIN users u ON e.created_by = u.id
        WHERE e.status = 'pending'
        ORDER BY e.created_at DESC
    ''').fetchall()
    
    conn.close()
    return render_template('pending_routes.html', user=user, routes=routes)

@eco_routes_bp.route('/eco-route/approve/<int:route_id>')
@admin_required
def approve_route(route_id):
    conn = get_db()
    route = conn.execute('SELECT name FROM eco_routes WHERE id = ?', (route_id,)).fetchone()
    
    if route:
        conn.execute('UPDATE eco_routes SET status = "approved" WHERE id = ?', (route_id,))
        conn.commit()
        flash(f'✅ Маршрут "{route["name"]}" одобрен!', 'success')
    else:
        flash('❌ Маршрут не найден', 'danger')
    
    conn.close()
    return redirect(url_for('notifications.admin_notifications'))

@eco_routes_bp.route('/eco-route/reject/<int:route_id>')
@admin_required
def reject_route(route_id):
    conn = get_db()
    route = conn.execute('SELECT name FROM eco_routes WHERE id = ?', (route_id,)).fetchone()
    
    if route:
        conn.execute('UPDATE eco_routes SET status = "rejected" WHERE id = ?', (route_id,))
        conn.commit()
        flash(f'❌ Маршрут "{route["name"]}" отклонен', 'warning')
    else:
        flash('❌ Маршрут не найден', 'danger')
    
    conn.close()
    return redirect(url_for('notifications.admin_notifications'))  

# УДАЛЕНИЕ МАРШРУТА 

@eco_routes_bp.route('/eco-route/delete/<int:route_id>', methods=['POST'])
@login_required
def delete_route(route_id):
    """Удаление маршрута (админ может всё, исследователь - только свой)"""
    user = get_current_user()
    conn = get_db()
    
    # Получаем информацию о маршруте
    route = conn.execute('SELECT * FROM eco_routes WHERE id = ?', (route_id,)).fetchone()
    
    if not route:
        conn.close()
        flash('❌ Маршрут не найден', 'danger')
        return redirect(url_for('eco_routes.eco_routes_list'))
    
    # АДМИН МОЖЕТ УДАЛЯТЬ ВСЁ МУХААХАХААХАХ
    if user['role'] == 'admin':
        # Удаляем точки маршрута
        conn.execute('DELETE FROM route_points WHERE route_id = ?', (route_id,))
        # Удаляем сам маршрут
        conn.execute('DELETE FROM eco_routes WHERE id = ?', (route_id,))
        conn.commit()
        conn.close()
        flash('✅ Маршрут удален администратором', 'success')
        return redirect(url_for('admin.admin_panel'))
    
    # ИССЛЕДОВАТЕЛЬ МОЖЕТ УДАЛЯТЬ ТОЛЬКО СВОЁ!!!!!!!!
    elif user['role'] == 'researcher' and route['created_by'] == user['id']:
        # Проверяем, не одобрен ли уже маршрут
        if route['status'] == 'approved':
            conn.close()
            flash('❌ Нельзя удалить одобренный маршрут. Обратитесь к администратору', 'danger')
            return redirect(url_for('eco_routes.eco_routes_list'))
        
        # Удаляем точки маршрута
        conn.execute('DELETE FROM route_points WHERE route_id = ?', (route_id,))
        # Удаляем сам маршрут
        conn.execute('DELETE FROM eco_routes WHERE id = ?', (route_id,))
        conn.commit()
        conn.close()
        flash('✅ Ваш маршрут удален', 'success')
        return redirect(url_for('eco_routes.eco_routes_list'))
    
    # ТУРИСТ ИЛИ ЧУЖОЙ МАРШРУТ
    else:
        conn.close()
        flash('❌ У вас нет прав для удаления этого маршрута', 'danger')
        return redirect(url_for('eco_routes.eco_routes_list'))

# API МАРШРУТОВ 

@eco_routes_bp.route('/api/eco-routes')
def api_eco_routes():
    """API для получения списка маршрутов (для карты)"""
    conn = get_db()
    routes = conn.execute('''
        SELECT id, name, description, difficulty, length_km, duration_hours, created_by, status
        FROM eco_routes 
        WHERE status = 'approved'
        ORDER BY created_at DESC
    ''').fetchall()
    conn.close()
    
    routes_list = []
    for route in routes:
        routes_list.append({
            'id': route['id'],
            'name': route['name'],
            'description': route['description'],
            'difficulty': route['difficulty'],
            'length_km': route['length_km'],
            'duration_hours': route['duration_hours'],
            'status': route['status']
        })
    
    return jsonify(routes_list)

@eco_routes_bp.route('/api/eco-route/<int:route_id>/geojson')
def api_eco_route_geojson(route_id):
    """API для получения GeoJSON маршрута"""
    conn = get_db()
    
    # Проверяем статус маршрута
    route = conn.execute('SELECT * FROM eco_routes WHERE id = ?', (route_id,)).fetchone()
    
    if not route:
        conn.close()
        return jsonify({"error": "Маршрут не найден"}), 404
    
    # Для неодобренных маршрутов показываем только админу и автору
    user = get_current_user()
    if route['status'] != 'approved' and not (user and (user['role'] == 'admin' or user['id'] == route['created_by'])):
        conn.close()
        return jsonify({"error": "Маршрут недоступен"}), 403
    
    points = conn.execute('''
        SELECT latitude, longitude, order_index, title, description
        FROM route_points
        WHERE route_id = ?
        ORDER BY order_index
    ''', (route_id,)).fetchall()
    
    conn.close()
    
    # Если нет точек,то возвращаем пустой маршрут с тестовыми координатами
    coordinates = []
    if points:
        coordinates = [[float(p['longitude']), float(p['latitude'])] for p in points]
    else:
        # Тестовые координаты для маршрута без точек
        coordinates = [[37.6173, 55.7558], [37.6273, 55.7658], [37.6373, 55.7758]]
    
    geojson = {
        "type": "FeatureCollection",
        "features": [{
            "type": "Feature",
            "properties": {
                "name": route['name'],
                "description": route['description'],
                "difficulty": route['difficulty'],
                "length_km": route['length_km'],
                "duration_hours": route['duration_hours'],
                "status": route['status']
            },
            "geometry": {
                "type": "LineString",
                "coordinates": coordinates
            }
        }]
    }
    
    return jsonify(geojson)

# СТАТЫ

@eco_routes_bp.route('/api/eco-routes/stats')
def api_eco_routes_stats():
    """API для получения статистики по маршрутам"""
    conn = get_db()
    
    total = conn.execute('SELECT COUNT(*) as count FROM eco_routes WHERE status = "approved"').fetchone()['count']
    by_difficulty = conn.execute('''
        SELECT difficulty, COUNT(*) as count 
        FROM eco_routes 
        WHERE status = "approved"
        GROUP BY difficulty
    ''').fetchall()
    
    conn.close()
    
    stats = {
        'total': total,
        'by_difficulty': {row['difficulty']: row['count'] for row in by_difficulty}
    }
    
    return jsonify(stats)