from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from ..models.database import get_db
from ..utils.decorators import login_required, get_current_user, researcher_required, admin_required, can_edit_item
from .notifications import create_notification

species_bp = Blueprint('species', __name__)

@species_bp.route('/species')
def species_list():
    user = get_current_user()
    conn = get_db()
    # Показываем только одобренные виды для всех
    species = conn.execute('SELECT * FROM species WHERE status = "approved" ORDER BY name').fetchall()
    conn.close()
    return render_template('species.html', user=user, species=species)

@species_bp.route('/species/pending')
@admin_required
def pending_species():
    """Страница с видами на модерации (только для админа)"""
    user = get_current_user()
    conn = get_db()
    
    species = conn.execute('''
        SELECT s.*, u.username 
        FROM species s
        JOIN users u ON s.user_id = u.id
        WHERE s.status = 'pending'
        ORDER BY s.created_at DESC
    ''').fetchall()
    
    conn.close()
    return render_template('pending_species.html', user=user, species=species)

@species_bp.route('/species/<int:species_id>')
def species_detail(species_id):
    user = get_current_user()
    conn = get_db()
    species = conn.execute('SELECT * FROM species WHERE id = ?', (species_id,)).fetchone()
    
    if not species:
        conn.close()
        flash('Вид не найден', 'danger')
        return redirect(url_for('species.species_list'))
    
    # Показываем наблюдения этого вида
    observations = conn.execute('''
        SELECT o.*, u.username
        FROM observations o
        JOIN users u ON o.user_id = u.id
        WHERE o.species_id = ?
        ORDER BY o.observation_date DESC
        LIMIT 20
    ''', (species_id,)).fetchall()
    
    conn.close()
    return render_template('species_detail.html', user=user, species=species, observations=observations)

@species_bp.route('/species/add', methods=['GET', 'POST'])
@researcher_required
def add_species():
    user = get_current_user()
    
    if request.method == 'POST':
        name = request.form['name']
        latin_name = request.form.get('latin_name', '')
        category = request.form['category']
        description = request.form.get('description', '')
        conservation_status = request.form.get('conservation_status', 'Не указан')
        
        conn = get_db()
        try:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO species (name, latin_name, category, description, conservation_status, user_id, status)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (name, latin_name, category, description, conservation_status, user['id'], 'pending'))
            
            species_id = cursor.lastrowid
            conn.commit()
            
            # Создаем уведомление для админа
            create_notification(
                type='species',
                item_id=species_id,
                item_name=name,
                user_id=user['id'],
                message=f'Исследователь {user["username"]} предложил новый вид: {name}'
            )
            
            flash(f'✅ Вид "{name}" отправлен на модерацию!', 'success')
        except Exception as e:
            flash(f'❌ Ошибка: {str(e)}', 'danger')
        finally:
            conn.close()
        
        return redirect(url_for('species.species_list'))
    
    return render_template('add_species.html', user=user)

@species_bp.route('/species/approve/<int:species_id>')
@admin_required
def approve_species(species_id):
    conn = get_db()
    conn.execute('UPDATE species SET status = "approved" WHERE id = ?', (species_id,))
    conn.commit()
    conn.close()
    flash('✅ Вид одобрен!', 'success')
    return redirect(url_for('notifications.admin_notifications'))

@species_bp.route('/species/reject/<int:species_id>')
@admin_required
def reject_species(species_id):
    conn = get_db()
    conn.execute('DELETE FROM species WHERE id = ?', (species_id,))
    conn.commit()
    conn.close()
    flash('❌ Вид отклонен', 'warning')
    return redirect(url_for('notifications.admin_notifications'))

@species_bp.route('/species/delete/<int:species_id>', methods=['POST'])
@login_required
def delete_species(species_id):
    """Удаление вида (админ может всё, исследователь - только своё)"""
    user = get_current_user()
    conn = get_db()
    
    # Получаем информацию о виде
    species = conn.execute('SELECT * FROM species WHERE id = ?', (species_id,)).fetchone()
    
    if not species:
        conn.close()
        flash('❌ Вид не найден', 'danger')
        return redirect(url_for('species.species_list'))
    
    # АДМИН МОЖЕТ УДАЛЯТЬ ВСЁ, КАК ВСЕГДА
    if user['role'] == 'admin':
        # Удаляем все наблюдения этого вида
        conn.execute('DELETE FROM observations WHERE species_id = ?', (species_id,))
        # Удаляем сам вид
        conn.execute('DELETE FROM species WHERE id = ?', (species_id,))
        conn.commit()
        conn.close()
        flash('✅ Вид и все связанные наблюдения удалены администратором', 'success')
        return redirect(url_for('admin.admin_panel'))
    
    # ИССЛЕДОВАТЕЛЬ МОЖЕТ УНИЧТОЖАТЬ ТОЛЬКО СВОЙ ВИД
    elif user['role'] == 'researcher' and species['user_id'] == user['id']:
        # Проверяем, не одобрен ли уже вид
        if species['status'] == 'approved':
            conn.close()
            flash('❌ Нельзя удалить одобренный вид. Обратитесь к администратору', 'danger')
            return redirect(url_for('species.species_list'))
        
        conn.execute('DELETE FROM species WHERE id = ?', (species_id,))
        conn.commit()
        conn.close()
        flash('✅ Ваш вид удален', 'success')
        return redirect(url_for('species.species_list'))
    
    # ТУРИСТ ИЛИ ЧУЖОЙ ВИД
    else:
        conn.close()
        flash('❌ У вас нет прав для удаления этого вида', 'danger')
        return redirect(url_for('species.species_list'))