from flask import Flask
import os

def create_app():
    app = Flask(__name__)
    
    # Конфигурация
    app.config['SECRET_KEY'] = 'eco-tourism-secret-key-2024'
    app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'uploads')
    app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
    
    # Создаем папки
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    print(f"📁 ПАПКА ЗАГРУЗОК: {app.config['UPLOAD_FOLDER']}")
    
    # Инициализация БД
    from app.models.database import init_db
    init_db()
    
    # Импортируем все Blueprints
    from app.routes.main import main_bp
    from app.routes.auth import auth_bp
    from app.routes.observations import observations_bp
    from app.routes.species import species_bp
    from app.routes.eco_routes import eco_routes_bp
    from app.routes.notifications import notifications_bp
    from app.routes.admin import admin_bp
    
    # Регистрируем все Blueprints
    app.register_blueprint(main_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(observations_bp)
    app.register_blueprint(species_bp)
    app.register_blueprint(eco_routes_bp)
    app.register_blueprint(notifications_bp)
    app.register_blueprint(admin_bp)
    
    return app