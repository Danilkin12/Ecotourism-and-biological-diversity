from PIL import Image, ImageDraw

# Создаем изображение 32x32
img = Image.new('RGBA', (32, 32), color=(46, 125, 50, 255))  # #2e7d32
draw = ImageDraw.Draw(img)

# Рисуем лист
draw.ellipse([8, 8, 24, 24], fill=(76, 175, 80, 255))  # #4caf50

# Рисуем прожилки
draw.line([16, 8, 16, 24], fill=(255, 255, 255, 255), width=2)
draw.line([12, 12, 20, 20], fill=(255, 255, 255, 255), width=2)
draw.line([20, 12, 12, 20], fill=(255, 255, 255, 255), width=2)

# Сохраняем как ICO
img.save('app/static/favicon.ico', format='ICO', sizes=[(32, 32)])

# Создаем PNG для других размеров
img.save('app/static/favicon-32x32.png', format='PNG')
img.save('app/static/favicon-16x16.png', format='PNG')

# Создаем Apple Touch Icon
apple_img = img.resize((180, 180), Image.Resampling.LANCZOS)
apple_img.save('app/static/apple-touch-icon.png', format='PNG')