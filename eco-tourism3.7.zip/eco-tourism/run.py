from app import create_app

app = create_app()

if __name__ == '__main__':
    print("=" * 60)
    print("🌿 ЭКО-ТУРИЗМ И БИОРАЗНООБРАЗИЕ")
    print("=" * 60)
    print("✅ Сервер запущен: http://127.0.0.1:5000")
    print("✅ База данных: eco_tourism.db")
    print("\n📋 ТЕСТОВЫЕ АККАУНТЫ:")
    print("   Администратор: admin / admin123")
    print("   Исследователь: researcher / pass123")
    print("   Турист: tourist / pass123")
    print("=" * 60)
    app.run(debug=True, host='127.0.0.1', port=5000)